#!/bin/bash

# Grading uses the extractor output captured by _bin/prestop inside the
# student's container. Keep pregrade quiet so it does not create a shadow result.
exit 0
