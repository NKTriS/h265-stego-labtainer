#!/usr/bin/env python3
"""Check decode errors and PSNR between clean.hevc and evidence.hevc."""

from __future__ import annotations

import argparse
import re
import subprocess
from pathlib import Path


def run_ffmpeg(args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, text=True, capture_output=True, check=False)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("clean", type=Path)
    parser.add_argument("evidence", type=Path)
    args = parser.parse_args()

    decode = run_ffmpeg(["ffmpeg", "-v", "error", "-i", str(args.evidence), "-f", "null", "-"])
    decode_errors = len([line for line in decode.stderr.splitlines() if line.strip()])

    psnr = run_ffmpeg(
        [
            "ffmpeg",
            "-i",
            str(args.clean),
            "-i",
            str(args.evidence),
            "-lavfi",
            "psnr",
            "-f",
            "null",
            "-",
        ]
    )
    combined = psnr.stdout + "\n" + psnr.stderr
    match = re.search(r"PSNR y:([^\s]+)", combined)
    y_value = match.group(1) if match else "inf"
    if y_value.lower() != "inf":
        y_value = f"{float(y_value):.2f}"

    print(f"DECODE_ERRORS={decode_errors}")
    print(f"PSNR_Y={y_value}")
    print(f"PSNR_TOKEN={y_value}:{decode_errors}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
