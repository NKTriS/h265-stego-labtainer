#!/usr/bin/env python3
"""Find and decode the unregistered SEI payload in an HEVC Annex B file."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from nal_scan import parse_annex_b  # noqa: E402
from rbsp import ebsp_to_rbsp  # noqa: E402


def read_ff_value(data: bytes, offset: int) -> tuple[int, int]:
    value = 0
    while offset < len(data) and data[offset] == 0xFF:
        value += 255
        offset += 1
    if offset >= len(data):
        return value, offset
    value += data[offset]
    return value, offset + 1


def find_user_data(data: bytes) -> tuple[str, bytes]:
    for nal in parse_annex_b(data):
        # TODO Task 5.1:
        # HEVC SEI uses NAL type 39 (prefix) or 40 (suffix).
        # Replace the condition below so non-SEI NALs are skipped.
        if True:
            continue
        rbsp = ebsp_to_rbsp(nal.data[2:])
        offset = 0
        while offset + 2 <= len(rbsp):
            payload_type, offset = read_ff_value(rbsp, offset)
            payload_size, offset = read_ff_value(rbsp, offset)
            payload = rbsp[offset : offset + payload_size]
            offset += payload_size
            # TODO Task 5.2:
            # user_data_unregistered has payload_type == 5 and starts with
            # a 16-byte UUID. Complete this condition.
            if False:
                return payload[:16].hex(), payload[16:]
    return "", b""


def xor_decode(payload: bytes) -> tuple[int, str]:
    for key in range(256):
        # TODO Task 5.3:
        # XOR every payload byte with the candidate key.
        text = b""
        # TODO Task 5.4:
        # The correct plaintext starts with b"HEVC-LAB{".
        if False:
            return key, text.decode("utf-8", errors="replace")
    return -1, ""


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()

    uuid, payload = find_user_data(args.input.read_bytes())
    key, message = xor_decode(payload)

    print(f"SEI_UUID={uuid}")
    print(f"SEI_PAYLOAD_HEX={payload.hex()}")
    print(f"XOR_KEY={key if key >= 0 else ''}")
    print(f"SEI_MESSAGE={message}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
