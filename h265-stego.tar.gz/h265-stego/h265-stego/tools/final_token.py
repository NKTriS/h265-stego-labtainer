#!/usr/bin/env python3
"""Recover both hidden messages and print the final lab token."""

from __future__ import annotations

import argparse
import hashlib
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def value_from_output(output: str, key: str) -> str:
    prefix = f"{key}="
    for line in output.splitlines():
        if line.startswith(prefix):
            return line[len(prefix) :]
    return ""


def run_tool(tool: str, *args: Path) -> str:
    command = [sys.executable, str(ROOT / "tools" / tool), *(str(arg) for arg in args)]
    return subprocess.check_output(command, text=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()

    sei_output = run_tool("sei_probe.py", args.input)
    vcl_output = run_tool("vcl_extract.py", args.input)
    sei_message = value_from_output(sei_output, "SEI_MESSAGE")
    slice_message = value_from_output(vcl_output, "SLICE_MESSAGE")
    final = hashlib.sha256(f"{sei_message}|{slice_message}".encode()).hexdigest()[:16]

    print(f"SEI_MESSAGE={sei_message}")
    print(f"SLICE_MESSAGE={slice_message}")
    print(f"FINAL={final}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
