#!/usr/bin/env python3
"""Scan HEVC Annex B files and print NAL unit statistics."""

from __future__ import annotations

import argparse
from collections import Counter
from dataclasses import dataclass
from pathlib import Path


@dataclass
class NalUnit:
    index: int
    start_code_offset: int
    payload_offset: int
    end_offset: int
    start_code_size: int
    data: bytes

    @property
    def size(self) -> int:
        return len(self.data)

    @property
    def nal_type(self) -> int:
        if len(self.data) < 2:
            return -1
        return (self.data[0] >> 1) & 0x3F

    @property
    def is_vcl(self) -> bool:
        return 0 <= self.nal_type <= 31


def _start_code_size_at(data: bytes, offset: int) -> int:
    if data[offset : offset + 4] == b"\x00\x00\x00\x01":
        return 4
    if data[offset : offset + 3] == b"\x00\x00\x01":
        return 3
    return 0


def find_start_codes(data: bytes) -> list[tuple[int, int]]:
    codes: list[tuple[int, int]] = []
    i = 0
    while i < len(data) - 3:
        size = _start_code_size_at(data, i)
        if size:
            codes.append((i, size))
            i += size
        else:
            i += 1
    return codes


def parse_annex_b(data: bytes) -> list[NalUnit]:
    starts = find_start_codes(data)
    nals: list[NalUnit] = []
    for idx, (start, code_size) in enumerate(starts):
        payload_offset = start + code_size
        end = starts[idx + 1][0] if idx + 1 < len(starts) else len(data)
        if end > payload_offset:
            nals.append(
                NalUnit(
                    index=len(nals),
                    start_code_offset=start,
                    payload_offset=payload_offset,
                    end_offset=end,
                    start_code_size=code_size,
                    data=data[payload_offset:end],
                )
            )
    return nals


def nal_type_name(nal_type: int) -> str:
    names = {
        19: "IDR_W_RADL",
        20: "IDR_N_LP",
        32: "VPS",
        33: "SPS",
        34: "PPS",
        39: "PREFIX_SEI",
        40: "SUFFIX_SEI",
    }
    if 0 <= nal_type <= 31:
        return names.get(nal_type, "VCL")
    return names.get(nal_type, "NON_VCL")


def summary_string(nals: list[NalUnit]) -> str:
    counts = Counter(n.nal_type for n in nals)
    total = len(nals)
    vcl = sum(v for k, v in counts.items() if 0 <= k <= 31)
    sei = counts[39] + counts[40]
    return f"{total}:{counts[32]}:{counts[33]}:{counts[34]}:{sei}:{vcl}"


def serialize_annex_b(nals: list[NalUnit]) -> bytes:
    out = bytearray()
    for n in nals:
        out.extend(b"\x00\x00\x00\x01")
        out.extend(n.data)
    return bytes(out)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()

    data = args.input.read_bytes()
    nals = parse_annex_b(data)
    print("idx offset     size   type name")
    for n in nals:
        print(
            f"{n.index:3d} {n.payload_offset:8d} {n.size:6d} "
            f"{n.nal_type:4d} {nal_type_name(n.nal_type)}"
        )
    print()
    print(f"NAL_SUMMARY={summary_string(nals)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
