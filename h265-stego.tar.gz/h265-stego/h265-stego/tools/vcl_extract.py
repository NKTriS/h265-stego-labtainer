#!/usr/bin/env python3
"""Extract a small hidden message from VCL trailing zero bytes."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from nal_scan import parse_annex_b  # noqa: E402


def bits_to_text(bits: list[int]) -> str:
    out = bytearray()
    for i in range(0, len(bits) - 7, 8):
        value = 0
        for bit in bits[i : i + 8]:
            # TODO Task 6.3:
            # Build one byte from 8 bits, most-significant bit first.
            value = value
        if value == 0:
            break
        out.append(value)
    return out.decode("utf-8", errors="replace")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()

    bits: list[int] = []
    carriers = 0
    for nal in parse_annex_b(args.input.read_bytes()):
        # TODO Task 6.1:
        # Only VCL NALs carry the hidden slice bits in this lab.
        if True:
            continue
        # TODO Task 6.2:
        # Count how many zero bytes are at the end of this NAL payload.
        zero_count = 0
        if zero_count == 1:
            bits.append(0)
            carriers += 1
        elif zero_count == 2:
            bits.append(1)
            carriers += 1

    print(f"VCL_CARRIERS={carriers}")
    print(f"VCL_BITS={''.join(str(bit) for bit in bits)}")
    print(f"SLICE_MESSAGE={bits_to_text(bits)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
