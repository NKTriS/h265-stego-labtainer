#!/usr/bin/env python3
"""Helpers for HEVC EBSP/RBSP conversion."""

from __future__ import annotations


def ebsp_to_rbsp(ebsp: bytes) -> bytes:
    """Remove emulation-prevention bytes from an EBSP payload."""
    out = bytearray()
    zero_count = 0
    i = 0
    while i < len(ebsp):
        b = ebsp[i]
        if zero_count >= 2 and b == 0x03:
            zero_count = 0
            i += 1
            continue
        out.append(b)
        if b == 0:
            zero_count += 1
        else:
            zero_count = 0
        i += 1
    return bytes(out)


def rbsp_to_ebsp(rbsp: bytes) -> bytes:
    """Insert emulation-prevention bytes when serializing RBSP to EBSP."""
    out = bytearray()
    zero_count = 0
    for b in rbsp:
        if zero_count >= 2 and b <= 0x03:
            out.append(0x03)
            zero_count = 0
        out.append(b)
        if b == 0:
            zero_count += 1
        else:
            zero_count = 0
    return bytes(out)


def strip_rbsp_trailing_bits(rbsp: bytes) -> bytes:
    """Remove a simple rbsp_trailing_bits byte when present."""
    if rbsp.endswith(b"\x80"):
        return rbsp[:-1]
    return rbsp

