#!/usr/bin/env python3
"""Extractor skeleton for the H.265 steganography lab.

You are given two helper modules:
    tools/nal_scan.py  -> parse_annex_b(), summary_string()
    tools/rbsp.py      -> ebsp_to_rbsp(), strip_rbsp_trailing_bits()

Complete the TODO functions below. Labtainer checkwork will grade each output
line as a separate task.
"""

from __future__ import annotations

import argparse
import hashlib
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from nal_scan import NalUnit, parse_annex_b, summary_string  # noqa: E402
from rbsp import ebsp_to_rbsp, strip_rbsp_trailing_bits  # noqa: E402


def task1_nal_summary(nals: list[NalUnit]) -> str:
    """Return total:vps:sps:pps:sei:vcl."""
    # TODO: use summary_string(nals).
    return ""


def parse_sei_user_data(nals: list[NalUnit]) -> tuple[str, bytes]:
    """Return (uuid_hex, encrypted_payload) from SEI user_data_unregistered.

    Hints:
    - SEI NAL types are 39 and 40.
    - Skip the 2-byte H.265 NAL header.
    - Convert EBSP to RBSP before parsing.
    - SEI payload_type and payload_size use 0xff extension bytes.
    - user_data_unregistered has payload_type == 5.
    - Its payload is 16-byte UUID followed by user data.
    """
    # TODO: implement Task 2 here.
    return "", b""


def decode_xor_message(encrypted: bytes) -> str:
    """Brute-force one-byte XOR until the plaintext starts with HEVC-LAB{."""
    # TODO: implement Task 3 here.
    return ""


def extract_vcl_message(nals: list[NalUnit]) -> str:
    """Extract the hidden message from trailing zero bytes of VCL NALs.

    Lab rule:
    - VCL NAL type is 0..31.
    - 1 trailing zero byte means bit 0.
    - 2 trailing zero bytes mean bit 1.
    - Group bits into bytes, big-endian, stop at byte 0.
    """
    # TODO: implement Task 4 here.
    return ""


def compute_psnr_token(clean_path: Path, evidence_path: Path) -> str:
    """Return <psnr_y_2dec_or_inf>:<decode_error_count>."""
    # TODO: implement Task 5 here.
    #
    # Useful commands:
    #   ffmpeg -v error -i evidence/evidence.hevc -f null -
    #   ffmpeg -i evidence/clean.hevc -i evidence/evidence.hevc -lavfi psnr -f null -
    return ""


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    args = parser.parse_args()

    nals = parse_annex_b(args.input.read_bytes())

    nal_summary = task1_nal_summary(nals)
    sei_uuid, encrypted = parse_sei_user_data(nals)
    sei_message = decode_xor_message(encrypted)
    slice_message = extract_vcl_message(nals)
    psnr_token = compute_psnr_token(args.input.parent / "clean.hevc", args.input)
    final = hashlib.sha256(f"{sei_message}|{slice_message}".encode()).hexdigest()[:16]

    print(f"NAL_SUMMARY={nal_summary}")
    print(f"SEI_UUID={sei_uuid}")
    print(f"SEI_MESSAGE={sei_message}")
    print(f"SLICE_MESSAGE={slice_message}")
    print(f"PSNR_TOKEN={psnr_token}")
    print(f"FINAL={final}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
