# Bài lab: Phân tích giấu tin trong video H.265/HEVC

## 1. Giới thiệu chung

Bài thực hành này mô phỏng một tình huống phân tích pháp chứng số. Sinh viên nhận được một file video raw H.265/HEVC tên `evidence.hevc`. File này vẫn là một bitstream H.265 thật, có thể kiểm tra bằng các công cụ video thông thường, nhưng bên trong có chứa dữ liệu ẩn.

Trong bài lab, dữ liệu được giấu ở hai vị trí:

- metadata SEI `user_data_unregistered`, trong đó thông điệp bị XOR bằng một khóa 1 byte;
- vùng VCL slice, trong đó bit 0/1 được biểu diễn bằng số lượng byte `00` ở cuối một số NAL payload.

Sinh viên không cần nhập checkword thủ công. Labtainer tự chấm dựa trên các file kết quả được lưu trong thư mục `report/`.

## 2. Mục tiêu

Sau khi hoàn thành bài lab, sinh viên có thể:

- nhận biết raw HEVC bitstream và start code Annex B;
- dùng `ffprobe`, `xxd`, `strings`, `grep` để phân tích file nhị phân;
- đọc bảng NAL unit gồm VPS, SPS, PPS, SEI và VCL;
- sửa một vài đoạn Python nhỏ để giải mã thông điệp trong SEI và VCL;
- hiểu vì sao metadata và bitstream video có thể bị lợi dụng để tạo kênh giấu tin.

## 3. Tải và khởi động bài lab

Tải bài lab bằng `imodule`:

```bash
imodule https://github.com/NKTriS/h265-stego-labtainer/raw/refs/heads/main/h265-stego.tar.gz
```

Nếu máy không có `imodule`, dùng:

```bash
curl -L https://raw.githubusercontent.com/NKTriS/h265-stego-labtainer/main/h265-stego.tar.gz | tar -xz -C ~/labtainer/trunk/labs/
```

Khởi động lab:

```bash
cd ~/labtainer/labtainer-student
labtainer h265-stego
```

Làm bài trong terminal của container `workstation`. Các thư mục cần dùng:

```text
evidence/   chứa file video cần phân tích
tools/      chứa công cụ Python, trong đó có file cần sửa
report/     nơi lưu kết quả để Labtainer chấm
```

## 4. Thực hành

### Task 1: Kiểm tra thông tin video

Dùng `ffprobe` để lấy thông tin codec, chiều rộng, chiều cao và frame rate của file:

```text
evidence/evidence.hevc
```

Lưu kết quả vào:

```text
report/video_info.txt
```

Sau khi làm xong, xem lại bằng:

```bash
cat report/video_info.txt
```

Kết quả cần có dòng:

```text
codec_name=hevc
```

### Task 2: Quan sát header Annex B

Dùng `xxd` để xem một đoạn ngắn ở đầu file `evidence/evidence.hevc`. Không cần dump toàn bộ file.

Lưu kết quả vào:

```text
report/header_hex.txt
```

Xem lại bằng:

```bash
cat report/header_hex.txt
```

Kết quả cần thể hiện start code Annex B ở đầu file:

```text
00000000: 0000 0001
```

### Task 3: Quét NAL unit

Dùng công cụ:

```text
tools/nal_scan.py
```

để quét file:

```text
evidence/evidence.hevc
```

Lưu output vào:

```text
report/nal_scan.txt
```

Xem lại bằng:

```bash
cat report/nal_scan.txt
```

Kết quả cuối file cần có:

```text
NAL_SUMMARY=171:5:5:5:6:150
```

Ý nghĩa của chuỗi trên là:

```text
tổng_số_NAL:số_VPS:số_SPS:số_PPS:số_SEI:số_VCL
```

### Task 4: Tìm dấu vết SEI dạng chuỗi ASCII

Dùng `strings` kết hợp `grep` để tìm chuỗi ASCII trong `evidence/evidence.hevc`.

Chuỗi cần tìm bắt đầu bằng:

```text
HE265LAB
```

Lưu kết quả vào:

```text
report/sei_hint.txt
```

Xem lại bằng:

```bash
cat report/sei_hint.txt
```

Kết quả cần có:

```text
HE265LABSTEGO001
```

Đây là dấu hiệu cho thấy file có SEI bất thường, chưa phải thông điệp cuối cùng.

### Task 5: Sửa code giải mã SEI

Mở file:

```bash
nano tools/sei_probe.py
```

Hoàn thành các dòng `TODO` theo gợi ý trong file:

- chỉ xử lý NAL type `39` hoặc `40`;
- chỉ lấy SEI payload có `payload_type == 5`;
- bỏ qua 16 byte UUID ở đầu payload;
- thử XOR từng byte với khóa từ `0` đến `255`;
- plaintext đúng bắt đầu bằng `HEVC-LAB{`.

Sau khi sửa code, chạy tool với file `evidence/evidence.hevc` và lưu output vào:

```text
report/sei_decode.txt
```

Xem lại bằng:

```bash
cat report/sei_decode.txt
```

Kết quả cần có:

```text
SEI_MESSAGE=HEVC-LAB{metadata_is_not_pixels}
```

### Task 6: Sửa code tách thông điệp trong VCL slice

Mở file:

```bash
nano tools/vcl_extract.py
```

Quy tắc giấu tin trong task này:

- cuối VCL NAL có 1 byte `00` nghĩa là bit `0`;
- cuối VCL NAL có 2 byte `00` nghĩa là bit `1`;
- ghép 8 bit thành 1 byte theo thứ tự bit cao trước;
- gặp byte `0` thì dừng đọc thông điệp.

Hoàn thành các dòng `TODO` theo gợi ý trong file:

- chỉ xử lý NAL thuộc vùng VCL;
- đếm số byte `00` ở cuối `nal.data`;
- đổi `zero_count == 1` thành bit `0`;
- đổi `zero_count == 2` thành bit `1`;
- ghép bit thành ký tự ASCII.

Sau khi sửa code, chạy tool với file `evidence/evidence.hevc` và lưu output vào:

```text
report/vcl_message.txt
```

Xem lại bằng:

```bash
cat report/vcl_message.txt
```

Kết quả cần có:

```text
SLICE_MESSAGE=SLICE:qpel_path
```

## 5. Kiểm tra kết quả

Sau khi đã tạo đủ các file trong `report/`, quay lại terminal `student` bên ngoài container và chạy:

```bash
checkwork h265-stego
```

Kết quả đúng:

```text
Y - cw1
Y - cw2
Y - cw3
Y - cw4
Y - cw5
Y - cw6
```

Các file được chấm là:

```text
report/video_info.txt
report/header_hex.txt
report/nal_scan.txt
report/sei_hint.txt
report/sei_decode.txt
report/vcl_message.txt
```

## 6. Kết thúc bài lab

Kết thúc lab:

```bash
stoplab h265-stego
```

Làm lại từ đầu:

```bash
labtainer -r h265-stego
```
