# Bài lab: Phân tích giấu tin trong video H.265/HEVC

## 1. Giới thiệu chung về bài thực hành

Trong bài thực hành này, sinh viên đóng vai người phân tích pháp chứng số. Một file video raw H.265/HEVC có tên `evidence.hevc` được cung cấp và bị nghi ngờ có chứa thông điệp ẩn. Nhiệm vụ của sinh viên là kiểm tra file video, quan sát cấu trúc bitstream, tìm dấu vết metadata bất thường và hoàn thiện một vài đoạn code nhỏ để khôi phục thông điệp.

Khác với các bài giấu tin trên ảnh hoặc âm thanh, bài lab này không tập trung vào pixel hay sample. Dữ liệu được giấu trong cấu trúc nén của video HEVC, cụ thể là trong các NAL unit. Sinh viên sẽ làm việc với các thành phần như VPS, SPS, PPS, SEI và VCL slice.

Kịch bản của bài lab như sau:

Một file video HEVC được thu thập từ một nguồn đáng ngờ. Khi mở bằng trình phát video thông thường, file không có biểu hiện bất thường rõ ràng. Tuy nhiên, người phân tích nghi ngờ trong file có một kênh giấu tin. Sinh viên cần dùng công cụ dòng lệnh và Python để xác định file có đúng là video HEVC hay không, kiểm tra header, quét NAL unit, tìm dấu vết SEI và trích xuất thông điệp ẩn trong cả metadata lẫn slice dữ liệu video.

Bài lab gồm 6 task được chấm tự động bằng Labtainer. Sinh viên không cần nhập checkword thủ công. Mỗi task yêu cầu tạo một file kết quả trong thư mục `report/`.

## 2. Mục đích

Sau khi hoàn thành bài lab, sinh viên cần đạt được các mục tiêu sau:

(1) Hiểu video raw H.265/HEVC bitstream là gì và khác gì với container như `.mp4` hoặc `.mkv`.

(2) Biết dùng công cụ hệ thống để kiểm tra thông tin video, ví dụ codec, độ phân giải và frame rate.

(3) Biết quan sát dữ liệu nhị phân bằng hex để nhận diện start code Annex B `00 00 00 01`.

(4) Hiểu vai trò cơ bản của NAL unit trong HEVC, gồm VPS, SPS, PPS, SEI và VCL.

(5) Biết dùng `strings` để tìm dấu vết ASCII khả nghi trong file nhị phân.

(6) Biết đọc và sửa một số đoạn Python nhỏ để tách payload SEI, giải mã XOR và khôi phục dữ liệu ẩn trong VCL slice.

## 3. Yêu cầu đối với sinh viên

Sinh viên cần có kiến thức cơ bản về Linux và Python. Các thao tác cần dùng trong bài gồm:

- di chuyển và liệt kê thư mục;
- đọc nội dung file bằng `cat`;
- chuyển hướng output vào file bằng ký tự `>`;
- dùng các công cụ như `ffprobe`, `xxd`, `strings`, `grep`;
- mở và sửa file bằng `nano`;
- chạy script Python.

Trong quá trình làm bài, kết quả của từng task phải được lưu đúng tên file trong thư mục `report/`. Nếu chỉ in kết quả ra màn hình mà không lưu vào file, Labtainer có thể không chấm được.

## 4. Tải và khởi động bài lab

Tải bài lab bằng `imodule`:

```bash
imodule https://github.com/NKTriS/h265-stego-labtainer/raw/refs/heads/main/h265-stego.tar.gz
```

Nếu môi trường không có `imodule`, có thể tải bằng `curl`:

```bash
curl -L https://raw.githubusercontent.com/NKTriS/h265-stego-labtainer/main/h265-stego.tar.gz | tar -xz -C ~/labtainer/trunk/labs/
```

Khởi động bài lab:

```bash
cd ~/labtainer/labtainer-student
labtainer h265-stego
```

Sau khi lab mở, sinh viên làm bài trong terminal có dạng:

```text
ubuntu@h265-stego:~$
```

Các thư mục chính trong lab:

```text
evidence/   chứa file video cần phân tích
tools/      chứa công cụ hỗ trợ và file Python cần sửa
report/     nơi lưu kết quả để Labtainer chấm
solution/   nơi sinh viên có thể tự viết extractor nâng cao nếu muốn
```

Các file quan trọng:

```text
evidence/evidence.hevc
evidence/clean.hevc
tools/nal_scan.py
tools/sei_probe.py
tools/vcl_extract.py
tools/quality_check.py
tools/final_token.py
```

Trong đó, `nal_scan.py`, `sei_probe.py` và `vcl_extract.py` là các file dùng trực tiếp trong bài. Hai file `quality_check.py` và `final_token.py` là phần tham khảo thêm sau khi hoàn thành 6 task chính.

## 5. Nội dung thực hành

### Task 1: Kiểm tra thông tin video

Mục tiêu của task này là xác định `evidence.hevc` có phải là video HEVC thật hay không.

Sinh viên cần dùng `ffprobe` để lấy các thông tin chính của stream video:

- codec;
- chiều rộng;
- chiều cao;
- frame rate.

Kết quả cần lưu vào:

```text
report/video_info.txt
```

Sau khi tạo file, xem lại bằng:

```bash
cat report/video_info.txt
```

File kết quả cần thể hiện video dùng codec HEVC. Dòng quan trọng cần xuất hiện là:

```text
codec_name=hevc
```

### Task 2: Quan sát header Annex B

Mục tiêu của task này là kiểm tra phần đầu file ở dạng hex để nhận diện raw HEVC Annex B bitstream.

Sinh viên cần dùng `xxd` để xem một đoạn ngắn ở đầu file `evidence.hevc`. Không cần dump toàn bộ file vì file video có dung lượng lớn.

Kết quả cần lưu vào:

```text
report/header_hex.txt
```

Sau khi tạo file, xem lại bằng:

```bash
cat report/header_hex.txt
```

File kết quả cần có start code Annex B ở đầu:

```text
00000000: 0000 0001
```

Ý nghĩa: chuỗi byte `00 00 00 01` đánh dấu điểm bắt đầu của một NAL unit trong HEVC Annex B.

### Task 3: Quét cấu trúc NAL unit

Mục tiêu của task này là xem file HEVC gồm những loại NAL unit nào.

Sinh viên cần dùng công cụ:

```text
tools/nal_scan.py
```

để quét file:

```text
evidence/evidence.hevc
```

Kết quả cần lưu vào:

```text
report/nal_scan.txt
```

Sau khi tạo file, xem lại bằng:

```bash
cat report/nal_scan.txt
```

Khi đọc kết quả, chú ý các cột:

- `idx`: số thứ tự NAL;
- `offset`: vị trí trong file;
- `size`: kích thước NAL;
- `type`: loại NAL;
- `name`: tên gợi nhớ của NAL.

Cuối file báo cáo cần có dòng tổng hợp:

```text
NAL_SUMMARY=171:5:5:5:6:150
```

Dòng này có nghĩa là:

```text
tổng_số_NAL:số_VPS:số_SPS:số_PPS:số_SEI:số_VCL
```

### Task 4: Tìm dấu vết metadata SEI

Mục tiêu của task này là tìm chuỗi ASCII khả nghi trong file video. Đây là bước giúp sinh viên xác định vùng metadata có thể chứa dữ liệu ẩn.

Sinh viên cần dùng `strings` để trích các chuỗi có thể đọc được từ file nhị phân, sau đó lọc chuỗi liên quan đến bài lab. Chuỗi cần tìm bắt đầu bằng:

```text
HE265LAB
```

Kết quả cần lưu vào:

```text
report/sei_hint.txt
```

Sau khi tạo file, xem lại bằng:

```bash
cat report/sei_hint.txt
```

File kết quả cần có:

```text
HE265LABSTEGO001
```

Đây là dấu vết cho thấy trong video có metadata SEI bất thường. Đây chưa phải thông điệp bí mật cuối cùng.

### Task 5: Sửa code để giải mã thông điệp trong SEI

Mục tiêu của task này là hoàn thiện một số dòng code để trích xuất payload trong SEI `user_data_unregistered` và giải mã thông điệp bị XOR.

File cần sửa:

```text
tools/sei_probe.py
```

Mở file bằng `nano`:

```bash
nano tools/sei_probe.py
```

Trong file có các vị trí TODO của Task 5. Sinh viên cần hoàn thiện theo các ý sau:

(1) Chỉ xử lý NAL thuộc loại SEI. Trong HEVC, SEI có NAL type `39` hoặc `40`.

(2) Trong SEI, payload `user_data_unregistered` có `payload_type == 5`.

(3) Payload hợp lệ bắt đầu bằng UUID dài 16 byte. Phần sau UUID là dữ liệu bị mã hóa.

(4) Thông điệp bị XOR bằng khóa một byte. Cần thử khóa từ `0` đến `255`.

(5) Plaintext đúng bắt đầu bằng:

```text
HEVC-LAB{
```

Sau khi sửa code, chạy chương trình với file `evidence/evidence.hevc` và lưu output vào:

```text
report/sei_decode.txt
```

Sau khi tạo file, xem lại bằng:

```bash
cat report/sei_decode.txt
```

File kết quả cần có:

```text
SEI_MESSAGE=HEVC-LAB{metadata_is_not_pixels}
```

### Task 6: Sửa code để tách thông điệp trong VCL slice

Mục tiêu của task này là hoàn thiện một số dòng code để tách thông điệp được giấu trong vùng VCL slice của video.

File cần sửa:

```text
tools/vcl_extract.py
```

Mở file bằng `nano`:

```bash
nano tools/vcl_extract.py
```

Trong bài lab này, thông điệp VCL được giấu bằng số lượng byte `00` ở cuối payload của một số VCL NAL:

(1) Nếu cuối NAL có 1 byte `00`, bit được giấu là `0`.

(2) Nếu cuối NAL có 2 byte `00`, bit được giấu là `1`.

(3) Ghép 8 bit thành 1 byte theo thứ tự bit cao trước.

(4) Khi gặp byte có giá trị `0`, quá trình đọc thông điệp dừng lại.

Sinh viên cần hoàn thiện các TODO trong `vcl_extract.py` theo các ý sau:

- chỉ xử lý NAL thuộc vùng VCL;
- đếm số byte `00` ở cuối `nal.data`;
- chuyển `zero_count == 1` thành bit `0`;
- chuyển `zero_count == 2` thành bit `1`;
- ghép từng nhóm 8 bit thành ký tự ASCII.

Sau khi sửa code, chạy chương trình với file `evidence/evidence.hevc` và lưu output vào:

```text
report/vcl_message.txt
```

Sau khi tạo file, xem lại bằng:

```bash
cat report/vcl_message.txt
```

File kết quả cần có:

```text
SLICE_MESSAGE=SLICE:qpel_path
```

## 6. Kiểm tra kết quả bài thực hành

Sau khi hoàn thành các task và đã tạo đủ file trong thư mục `report/`, sinh viên kiểm tra kết quả bằng lệnh sau ở terminal Labtainer bên ngoài:

```bash
checkwork h265-stego
```

Kết quả đúng khi hoàn thành toàn bộ bài:

```text
Y - cw1
Y - cw2
Y - cw3
Y - cw4
Y - cw5
Y - cw6
```

Các file được chấm tự động:

```text
report/video_info.txt
report/header_hex.txt
report/nal_scan.txt
report/sei_hint.txt
report/sei_decode.txt
report/vcl_message.txt
```

## 7. Phần tham khảo thêm

Sau khi hoàn thành 6 task chính, sinh viên có thể chạy thêm:

```text
tools/quality_check.py
```

Công cụ này kiểm tra video có lỗi giải mã hay không và so sánh chất lượng giữa video sạch với video có dữ liệu ẩn.

Sinh viên cũng có thể chạy:

```text
tools/final_token.py
```

Công cụ này ghép các thông điệp đã tìm được thành token cuối để đối chiếu.

Hai công cụ trên không phải phần chấm chính của `cw1` đến `cw6`.

## 8. Kết thúc bài lab

Khi hoàn thành bài thực hành, sinh viên có thể kết thúc lab bằng:

```bash
stoplab h265-stego
```

Nếu muốn làm lại từ đầu:

```bash
labtainer -r h265-stego
```

Lưu ý: chạy lại bằng `-r` sẽ xóa trạng thái làm bài hiện tại.
