# Bài lab: Phân tích giấu tin trong video H.265/HEVC

## Giới thiệu chung về bài thực hành

Trong bối cảnh bảo mật thông tin ngày càng phức tạp, kỹ thuật giấu tin (steganography) không chỉ được sử dụng để bảo vệ quyền riêng tư, thủy vân số hoặc truyền thông bí mật, mà còn có thể bị lợi dụng để che giấu dữ liệu trong các tệp đa phương tiện. Video là một môi trường đặc biệt phù hợp cho giấu tin vì có dung lượng lớn, cấu trúc phức tạp và chứa nhiều lớp dữ liệu khác nhau như metadata, frame, slice, thông tin codec và bitstream nén.

Bài thực hành này giúp sinh viên tìm hiểu và trực tiếp phân tích một file video theo chuẩn H.265/HEVC có chứa dữ liệu ẩn. Khác với các bài giấu tin trên ảnh hoặc âm thanh ở mức pixel/sample, bài lab này tập trung vào cấu trúc bitstream của video HEVC, đặc biệt là các NAL unit như VPS, SPS, PPS, SEI và VCL.

Trong bài lab, sinh viên đóng vai người phân tích pháp chứng số. Một file video raw HEVC tên là `evidence.hevc` được cung cấp và bị nghi ngờ có chứa thông điệp bí mật. Sinh viên cần sử dụng các công cụ dòng lệnh như `ffprobe`, `xxd`, `strings`, kết hợp với một số script Python hỗ trợ để xác định vị trí dữ liệu ẩn và khôi phục thông điệp.

Dữ liệu ẩn trong bài lab được cấy ở hai vị trí:

(1) Trong metadata SEI `user_data_unregistered`, payload được mã hóa bằng XOR một byte.

(2) Trong vùng VCL slice, thông điệp được biểu diễn bằng số lượng byte `00` ở cuối một số NAL payload.

Thông qua bài lab này, sinh viên sẽ hiểu rằng dữ liệu bí mật trong video không nhất thiết nằm trong pixel hiển thị, mà có thể nằm ở nhiều lớp thấp hơn trong cấu trúc nén của video.

## Mục đích

Bài thực hành nhằm giúp sinh viên tiếp cận quy trình phân tích giấu tin trong video H.265/HEVC, đồng thời rèn luyện kỹ năng sử dụng công cụ hệ thống và đọc hiểu mã nguồn Python ở mức vừa phải.

Thông qua bài thực hành, sinh viên sẽ đạt được các mục tiêu sau:

(1) Hiểu được video H.265/HEVC raw bitstream là gì và phân biệt với các container phổ biến như `.mp4`, `.mkv`.

(2) Biết cách sử dụng `ffprobe` để kiểm tra thông tin cơ bản của một stream video như codec, kích thước khung hình và frame rate.

(3) Biết cách sử dụng `xxd` để quan sát dữ liệu nhị phân và nhận diện start code Annex B `00 00 00 01`.

(4) Hiểu vai trò của NAL unit trong HEVC, bao gồm VPS, SPS, PPS, SEI và VCL.

(5) Biết cách dùng `strings` để tìm dấu vết ASCII khả nghi trong một file nhị phân.

(6) Hoàn thiện một vài đoạn code nhỏ để trích xuất payload SEI và giải mã thông điệp XOR.

(7) Hoàn thiện một vài đoạn code nhỏ để tách thông điệp được giấu trong các VCL slice.

(8) Biết cách sử dụng `checkwork` của Labtainer để kiểm tra kết quả sau khi đã tạo các file báo cáo.

## Yêu cầu đối với sinh viên

Sinh viên cần thực hiện đầy đủ các yêu cầu sau:

(1) Nắm được kiến thức cơ bản về giấu tin và tách tin trong dữ liệu đa phương tiện.

(2) Có hiểu biết cơ bản về video nén, đặc biệt là khái niệm frame, metadata, bitstream và NAL unit.

(3) Biết sử dụng một số lệnh Linux cơ bản như `ls`, `cat`, `grep`, chuyển hướng output bằng ký tự `>`.

(4) Biết sử dụng hoặc tra cứu cách dùng các công cụ `ffprobe`, `xxd`, `strings`.

(5) Biết đọc và chỉnh sửa Python ở mức cơ bản, ví dụ sửa điều kiện `if`, vòng lặp, xử lý bytes và chuỗi bit.

(6) Trong quá trình làm bài, sinh viên phải lưu kết quả từng nhiệm vụ vào thư mục `report/` để hệ thống có thể chấm tự động.

Bài lab không yêu cầu sinh viên nộp checkword thủ công. Các checkword được kiểm tra tự động thông qua file báo cáo và kết quả chạy chương trình.

## Mô hình bài lab

Bài lab gồm một container duy nhất:

```text
h265-stego
```

Khi khởi động lab, sinh viên làm việc trong terminal:

```text
ubuntu@h265-stego:~$
```

Các thư mục chính trong bài lab:

```text
evidence/
tools/
report/
solution/
```

Trong đó:

`evidence/`: chứa video cần phân tích.

`tools/`: chứa công cụ hỗ trợ và các file Python có đoạn TODO cần hoàn thiện.

`report/`: nơi sinh viên lưu kết quả để `checkwork` chấm.

`solution/`: thư mục phụ dành cho sinh viên muốn tự viết extractor nâng cao.

Các file quan trọng:

```text
evidence/evidence.hevc
evidence/clean.hevc
tools/nal_scan.py
tools/sei_probe.py
tools/vcl_extract.py
tools/quality_check.py
tools/final_token.py
```

Trong đó:

`evidence.hevc`: file video nghi có chứa dữ liệu ẩn.

`clean.hevc`: file video sạch dùng để đối chiếu chất lượng.

`nal_scan.py`: công cụ quét NAL unit.

`sei_probe.py`: file Python cần sửa TODO để phân tích SEI.

`vcl_extract.py`: file Python cần sửa TODO để tách thông điệp trong VCL.

`quality_check.py`: công cụ tham khảo để kiểm tra lỗi giải mã và PSNR.

`final_token.py`: công cụ tham khảo để ghép token cuối.

## Thực hành

### Tải bài lab

Sinh viên có thể tải bài lab theo cách giống các bài DSEC khác bằng `imodule`:

```bash
imodule https://github.com/NKTriS/h265-stego-labtainer/raw/refs/heads/main/h265-stego.tar.gz
```

Nếu môi trường Labtainer không có lệnh `imodule`, có thể dùng cách tải thủ công bằng `curl`:

```bash
curl -L https://raw.githubusercontent.com/NKTriS/h265-stego-labtainer/main/h265-stego.tar.gz | tar -xz -C ~/labtainer/trunk/labs/
```

### Khởi động bài lab

Tại terminal ngoài máy Labtainer, chạy:

```bash
cd ~/labtainer/labtainer-student
labtainer h265-stego
```

Sau khi lab khởi động, một terminal mới xuất hiện với prompt:

```text
ubuntu@h265-stego:~$
```

Sinh viên thực hiện các bước phân tích trong terminal này.

Lệnh `checkwork` được trình bày riêng ở mục kiểm tra kết quả. Trong từng task, sinh viên tập trung tạo đúng file báo cáo trong thư mục `report/` và dùng `cat` để tự xem nội dung file vừa tạo.

## Task 1: Kiểm tra thông tin video

### Mục tiêu

Xác định file `evidence.hevc` là một video HEVC thật và ghi lại các thông tin cơ bản của stream video.

### Yêu cầu thực hiện

Sinh viên sử dụng công cụ `ffprobe` để lấy các thông tin sau:

- codec video;
- chiều rộng;
- chiều cao;
- frame rate.

Kết quả cần được lưu vào:

```text
report/video_info.txt
```

Sau khi tạo file, xem lại nội dung bằng:

```bash
cat report/video_info.txt
```

### Gợi ý

Nên dùng các tùy chọn của `ffprobe` để chỉ lấy stream video đầu tiên và chỉ hiển thị các trường cần thiết. Không cần ghi toàn bộ log dài của `ffprobe`.

### Kiểm tra kết quả

File `report/video_info.txt` cần có nội dung thể hiện video sử dụng codec HEVC, ví dụ:

```text
codec_name=hevc
```

## Task 2: Quan sát header Annex B

### Mục tiêu

Kiểm tra phần đầu của file ở dạng hex để nhận diện raw HEVC Annex B bitstream.

### Yêu cầu thực hiện

Sinh viên sử dụng công cụ `xxd` để xem một đoạn ngắn đầu file `evidence.hevc`. Kết quả lưu vào:

```text
report/header_hex.txt
```

Sau khi tạo file, xem lại nội dung bằng:

```bash
cat report/header_hex.txt
```

### Gợi ý

Chỉ cần xem khoảng vài chục byte đầu file. Không cần dump toàn bộ file vì file video có dung lượng lớn.

### Kiểm tra kết quả

File báo cáo cần có start code Annex B:

```text
00000000: 0000 0001
```

Ý nghĩa:

`00 00 00 01` là start code đánh dấu điểm bắt đầu của một NAL unit trong HEVC Annex B.

## Task 3: Quét cấu trúc NAL unit

### Mục tiêu

Phân tích file HEVC ở mức NAL unit để biết video gồm những thành phần nào.

### Yêu cầu thực hiện

Sinh viên sử dụng công cụ:

```text
tools/nal_scan.py
```

để quét file:

```text
evidence/evidence.hevc
```

Kết quả cần lưu vào:

```text
report/nal_scan.txt
```

Sau khi tạo file, xem lại nội dung bằng:

```bash
cat report/nal_scan.txt
```

### Gợi ý

Quan sát các cột:

- `idx`: số thứ tự NAL;
- `offset`: vị trí trong file;
- `size`: kích thước NAL;
- `type`: loại NAL;
- `name`: tên gợi nhớ của NAL.

### Kiểm tra kết quả

Cuối file báo cáo cần có:

```text
NAL_SUMMARY=171:5:5:5:6:150
```

Ý nghĩa:

```text
tổng_số_NAL:số_VPS:số_SPS:số_PPS:số_SEI:số_VCL
```

## Task 4: Tìm dấu vết metadata SEI

### Mục tiêu

Tìm chuỗi ASCII khả nghi trong file video để xác định manh mối về vùng SEI.

### Yêu cầu thực hiện

Sinh viên sử dụng `strings` để trích các chuỗi ASCII có thể đọc được từ file nhị phân. Sau đó lọc chuỗi liên quan đến bài lab và lưu vào:

```text
report/sei_hint.txt
```

Sau khi tạo file, xem lại nội dung bằng:

```bash
cat report/sei_hint.txt
```

### Gợi ý

Chuỗi cần tìm bắt đầu bằng:

```text
HE265LAB
```

Có thể kết hợp `strings` với `grep`.

### Kiểm tra kết quả

File báo cáo cần có:

```text
HE265LABSTEGO001
```

Đây là dấu vết cho thấy trong file có metadata bất thường. Đây chưa phải thông điệp bí mật cuối cùng.

## Task 5: Sửa code để giải mã thông điệp trong SEI

### Mục tiêu

Hoàn thiện một số đoạn code nhỏ để trích xuất payload trong SEI `user_data_unregistered` và giải mã thông điệp bị XOR.

### File cần chỉnh sửa

```text
tools/sei_probe.py
```

Mở file bằng trình soạn thảo, ví dụ:

```bash
nano tools/sei_probe.py
```

Trong file có các vị trí:

```text
TODO Task 5.1
TODO Task 5.2
TODO Task 5.3
TODO Task 5.4
```

### Gợi ý thực hiện

Sinh viên cần hoàn thiện các ý sau:

(1) Chỉ xử lý các NAL loại SEI. Trong HEVC, SEI có NAL type `39` hoặc `40`.

(2) Trong SEI, payload `user_data_unregistered` có `payload_type == 5`.

(3) Payload hợp lệ bắt đầu bằng UUID dài 16 byte. Dữ liệu sau UUID là phần bị mã hóa.

(4) Thông điệp bị XOR bằng một khóa một byte. Cần thử các khóa từ `0` đến `255`.

(5) Plaintext đúng bắt đầu bằng:

```text
HEVC-LAB{
```

### Chạy chương trình

Sau khi sửa code, chạy `sei_probe.py` với file `evidence.hevc` và lưu output vào:

```text
report/sei_decode.txt
```

Sau khi tạo file, xem lại nội dung bằng:

```bash
cat report/sei_decode.txt
```

### Kiểm tra kết quả

File báo cáo cần có:

```text
SEI_MESSAGE=HEVC-LAB{metadata_is_not_pixels}
```

## Task 6: Sửa code để tách thông điệp trong VCL slice

### Mục tiêu

Hoàn thiện một số đoạn code nhỏ để tách thông điệp được giấu trong vùng VCL slice của video.

### File cần chỉnh sửa

```text
tools/vcl_extract.py
```

Mở file bằng trình soạn thảo:

```bash
nano tools/vcl_extract.py
```

Trong file có các vị trí:

```text
TODO Task 6.1
TODO Task 6.2
TODO Task 6.3
```

### Quy tắc giấu tin trong bài lab

Thông điệp được giấu bằng số lượng byte `00` ở cuối payload của một số VCL NAL:

(1) Nếu cuối NAL có 1 byte `00`, bit được giấu là `0`.

(2) Nếu cuối NAL có 2 byte `00`, bit được giấu là `1`.

(3) Ghép 8 bit thành 1 byte theo thứ tự bit cao trước.

(4) Khi gặp byte có giá trị `0`, quá trình đọc thông điệp dừng lại.

### Gợi ý thực hiện

Sinh viên cần hoàn thiện các ý sau:

- Chỉ xử lý NAL thuộc vùng VCL.
- Đếm số byte `00` ở cuối `nal.data`.
- Chuyển `zero_count == 1` thành bit `0`.
- Chuyển `zero_count == 2` thành bit `1`.
- Ghép từng nhóm 8 bit thành ký tự ASCII.

### Chạy chương trình

Sau khi sửa code, chạy `vcl_extract.py` với file `evidence.hevc` và lưu output vào:

```text
report/vcl_message.txt
```

Sau khi tạo file, xem lại nội dung bằng:

```bash
cat report/vcl_message.txt
```

### Kiểm tra kết quả

File báo cáo cần có:

```text
SLICE_MESSAGE=SLICE:qpel_path
```

## Kiểm tra kết quả bài thực hành bằng checkwork

Sau khi đã tạo các file báo cáo trong thư mục `report/`, sinh viên kiểm tra kết quả bằng lệnh:

```bash
checkwork h265-stego
```

Kết quả đúng sau khi hoàn thành toàn bộ bài:

```text
Y - cw1
Y - cw2
Y - cw3
Y - cw4
Y - cw5
Y - cw6
```

Các file được chấm:

```text
report/video_info.txt
report/header_hex.txt
report/nal_scan.txt
report/sei_hint.txt
report/sei_decode.txt
report/vcl_message.txt
```

## Phần tham khảo thêm

Sau khi hoàn thành `cw1` đến `cw6`, sinh viên có thể chạy thêm công cụ kiểm tra chất lượng video:

```text
tools/quality_check.py
```

Công cụ này kiểm tra:

- video có lỗi giải mã hay không;
- PSNR giữa video sạch và video có dữ liệu ẩn.

Kết quả mong đợi:

```text
DECODE_ERRORS=0
PSNR_TOKEN=inf:0
```

Sinh viên cũng có thể chạy:

```text
tools/final_token.py
```

để ghép hai thông điệp đã tìm được thành token cuối:

```text
FINAL=6d4bdd61ffd32cb2
```

## Một số lỗi thường gặp

### Chạy lệnh ở sai terminal

Nếu gặp lỗi:

```text
python3: can't open file 'tools/nal_scan.py'
```

có thể sinh viên đang chạy lệnh trong terminal `student@ubuntu` thay vì terminal lab `ubuntu@h265-stego`.

Lệnh làm bài chạy trong:

```text
ubuntu@h265-stego
```

Lệnh kiểm tra chạy trong:

```text
student@ubuntu
```

### Quên lưu kết quả vào thư mục report

Lab chấm các file trong thư mục `report/`. Nếu chỉ in kết quả ra màn hình mà không lưu vào file, `checkwork` có thể vẫn báo `N`.

Kiểm tra bằng:

```bash
ls -l report/
```

### Sửa code nhưng chưa chạy lại chương trình

Sau khi sửa `sei_probe.py` hoặc `vcl_extract.py`, sinh viên cần chạy lại chương trình và ghi output mới vào thư mục `report/`.

### Ghi sai tên file báo cáo

Tên file phải đúng như sau:

```text
report/video_info.txt
report/header_hex.txt
report/nal_scan.txt
report/sei_hint.txt
report/sei_decode.txt
report/vcl_message.txt
```

## Kết thúc bài lab

Khi hoàn thành bài thực hành, sinh viên có thể kết thúc lab bằng:

```bash
stoplab h265-stego
```

Nếu muốn làm lại từ đầu:

```bash
labtainer -r h265-stego
```

Lưu ý: chạy lại bằng `-r` sẽ xóa trạng thái làm bài hiện tại.

## Kết luận

Qua bài thực hành này, sinh viên đã thực hiện một quy trình phân tích giấu tin trong video H.265/HEVC gồm:

(1) Kiểm tra thông tin codec của video.

(2) Quan sát header raw bitstream.

(3) Quét cấu trúc NAL unit.

(4) Tìm dấu vết metadata SEI.

(5) Sửa code để giải mã thông điệp ẩn trong SEI.

(6) Sửa code để tách thông điệp ẩn trong VCL slice.

Bài lab cho thấy dữ liệu bí mật có thể được giấu trong nhiều lớp khác nhau của video, không chỉ nằm trong phần hình ảnh hiển thị. Việc phân tích video nghi có giấu tin đòi hỏi kết hợp giữa công cụ hệ thống, hiểu biết về chuẩn nén và khả năng đọc hiểu mã nguồn.
