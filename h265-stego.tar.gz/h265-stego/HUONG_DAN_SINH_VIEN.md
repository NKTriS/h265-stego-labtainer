# Bài lab: Phân tích giấu tin trong video H.265/HEVC

## 1. Giới thiệu chung

Bài thực hành này mô phỏng một tình huống phân tích pháp chứng số. Sinh viên nhận được một file video raw H.265/HEVC tên `evidence.hevc`. File này xem bên ngoài như một video bình thường, nhưng bị nghi ngờ có chứa thông điệp ẩn trong cấu trúc bitstream.

Nhiệm vụ của sinh viên là kiểm tra file video, quan sát dữ liệu nhị phân, quét các NAL unit, tìm dấu vết metadata bất thường và sửa một vài đoạn code Python nhỏ để khôi phục thông điệp ẩn.

Dữ liệu ẩn trong bài lab nằm ở hai vị trí:

(1) Metadata SEI `user_data_unregistered`, trong đó payload bị mã hóa bằng XOR một byte.

(2) Vùng VCL slice, trong đó bit được giấu bằng số lượng byte `00` ở cuối một số NAL payload.

Bài lab có 6 task. Sinh viên không cần nhập checkword thủ công. Labtainer sẽ tự chấm dựa trên các file kết quả trong thư mục `report/`.

## 2. Mục tiêu

Sau khi hoàn thành bài lab, sinh viên có thể:

- phân biệt raw HEVC bitstream với file video container như `.mp4`;
- dùng `ffprobe` để kiểm tra thông tin stream video;
- dùng `xxd` để nhận diện start code Annex B `00 00 00 01`;
- hiểu vai trò cơ bản của VPS, SPS, PPS, SEI và VCL trong HEVC;
- dùng `strings` để tìm dấu vết ASCII trong file nhị phân;
- sửa code Python đơn giản để giải mã SEI và tách dữ liệu trong VCL slice.

## 3. Yêu cầu

Sinh viên cần biết các thao tác Linux cơ bản như `ls`, `cat`, chuyển hướng output bằng `>`, dùng `grep`, mở file bằng `nano` và chạy Python.

Kết quả của mỗi task phải được lưu đúng tên file trong thư mục:

```text
report/
```

Nếu chỉ in kết quả ra màn hình mà không lưu vào file, hệ thống chấm có thể không ghi nhận.

## 4. Tải và khởi động bài lab

Tải bài lab bằng `imodule`:

```bash
imodule https://github.com/NKTriS/h265-stego-labtainer/raw/refs/heads/main/h265-stego.tar.gz
```

Nếu không có `imodule`, dùng:

```bash
curl -L https://raw.githubusercontent.com/NKTriS/h265-stego-labtainer/main/h265-stego.tar.gz | tar -xz -C ~/labtainer/trunk/labs/
```

Khởi động lab:

```bash
cd ~/labtainer/labtainer-student
labtainer h265-stego
```

Làm bài trong terminal:

```text
ubuntu@h265-stego:~$
```

Các thư mục chính:

```text
evidence/   file video cần phân tích
tools/      công cụ và code Python cần sửa
report/     nơi lưu kết quả để chấm
solution/   nơi tự viết extractor nếu muốn
```

Các file dùng trong bài:

```text
evidence/evidence.hevc
evidence/clean.hevc
tools/nal_scan.py
tools/sei_probe.py
tools/vcl_extract.py
tools/quality_check.py
tools/final_token.py
```

Trong đó, `nal_scan.py`, `sei_probe.py` và `vcl_extract.py` là các file dùng trực tiếp trong 6 task chính. Hai file `quality_check.py` và `final_token.py` là phần tham khảo thêm.

## 5. Thực hành

### Task 1: Kiểm tra thông tin video

Dùng `ffprobe` để lấy thông tin của `evidence/evidence.hevc`, gồm codec, chiều rộng, chiều cao và frame rate.

Lưu kết quả vào:

```text
report/video_info.txt
```

Xem lại file:

```bash
cat report/video_info.txt
```

Điều kiện đúng:

```text
codec_name=hevc
```

### Task 2: Quan sát header Annex B

Dùng `xxd` để xem một đoạn ngắn ở đầu file `evidence/evidence.hevc`. Không dump toàn bộ file.

Lưu kết quả vào:

```text
report/header_hex.txt
```

Xem lại file:

```bash
cat report/header_hex.txt
```

Điều kiện đúng:

```text
00000000: 0000 0001
```

`00 00 00 01` là start code đánh dấu điểm bắt đầu của một NAL unit trong HEVC Annex B.

### Task 3: Quét NAL unit

Dùng công cụ:

```text
tools/nal_scan.py
```

để quét:

```text
evidence/evidence.hevc
```

Lưu output vào:

```text
report/nal_scan.txt
```

Xem lại file:

```bash
cat report/nal_scan.txt
```

Khi đọc kết quả, chú ý các cột `idx`, `offset`, `size`, `type` và `name`.

Điều kiện đúng ở cuối file:

```text
NAL_SUMMARY=171:5:5:5:6:150
```

Ý nghĩa:

```text
tổng_số_NAL:số_VPS:số_SPS:số_PPS:số_SEI:số_VCL
```

### Task 4: Tìm dấu vết SEI

Dùng `strings` kết hợp lọc chuỗi để tìm dấu vết ASCII trong `evidence/evidence.hevc`.

Chuỗi cần tìm bắt đầu bằng:

```text
HE265LAB
```

Lưu kết quả vào:

```text
report/sei_hint.txt
```

Xem lại file:

```bash
cat report/sei_hint.txt
```

Điều kiện đúng:

```text
HE265LABSTEGO001
```

Đây là dấu hiệu có metadata SEI bất thường, chưa phải thông điệp cuối cùng.

### Task 5: Sửa code giải mã SEI

Mở file:

```bash
nano tools/sei_probe.py
```

Hoàn thành các vị trí TODO của Task 5 theo gợi ý:

- chỉ xử lý NAL SEI, tức NAL type `39` hoặc `40`;
- chỉ lấy payload `user_data_unregistered`, tức `payload_type == 5`;
- bỏ qua 16 byte UUID ở đầu payload;
- thử khóa XOR một byte từ `0` đến `255`;
- plaintext đúng bắt đầu bằng `HEVC-LAB{`.

Sau khi sửa code, chạy chương trình với `evidence/evidence.hevc` và lưu output vào:

```text
report/sei_decode.txt
```

Xem lại file:

```bash
cat report/sei_decode.txt
```

Điều kiện đúng:

```text
SEI_MESSAGE=HEVC-LAB{metadata_is_not_pixels}
```

### Task 6: Sửa code tách thông điệp trong VCL slice

Mở file:

```bash
nano tools/vcl_extract.py
```

Quy tắc giấu tin trong VCL:

- cuối NAL có 1 byte `00` nghĩa là bit `0`;
- cuối NAL có 2 byte `00` nghĩa là bit `1`;
- ghép 8 bit thành 1 byte theo thứ tự bit cao trước;
- gặp byte `0` thì dừng đọc thông điệp.

Hoàn thành các TODO của Task 6 theo gợi ý:

- chỉ xử lý NAL thuộc vùng VCL;
- đếm số byte `00` ở cuối `nal.data`;
- đổi `zero_count == 1` thành bit `0`;
- đổi `zero_count == 2` thành bit `1`;
- ghép bit thành ký tự ASCII.

Sau khi sửa code, chạy chương trình với `evidence/evidence.hevc` và lưu output vào:

```text
report/vcl_message.txt
```

Xem lại file:

```bash
cat report/vcl_message.txt
```

Điều kiện đúng:

```text
SLICE_MESSAGE=SLICE:qpel_path
```

## 6. Kiểm tra kết quả

Sau khi đã tạo đủ file trong `report/`, kiểm tra kết quả bằng lệnh sau ở terminal Labtainer bên ngoài:

```bash
checkwork h265-stego
```

Kết quả đúng:

```text
Y - cw1
Y - cw2
Y - cw3
Y - cw4
Y - cw5
Y - cw6
```

Các file được chấm:

```text
report/video_info.txt
report/header_hex.txt
report/nal_scan.txt
report/sei_hint.txt
report/sei_decode.txt
report/vcl_message.txt
```

## 7. Tham khảo thêm

Sau khi hoàn thành 6 task chính, có thể chạy thêm:

```text
tools/quality_check.py
tools/final_token.py
```

`quality_check.py` dùng để kiểm tra lỗi giải mã và chất lượng video.

`final_token.py` dùng để ghép các thông điệp đã tìm được thành token cuối.

Hai công cụ này không nằm trong phần chấm chính của `cw1` đến `cw6`.

## 8. Kết thúc bài lab

Kết thúc lab:

```bash
stoplab h265-stego
```

Làm lại từ đầu:

```bash
labtainer -r h265-stego
```

Lưu ý: chạy lại bằng `-r` sẽ xóa trạng thái làm bài hiện tại.
