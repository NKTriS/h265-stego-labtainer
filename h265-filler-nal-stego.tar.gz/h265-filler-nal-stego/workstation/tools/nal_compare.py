#!/usr/bin/env python3
import argparse
from collections import Counter
from hevc_filler_common import iter_nals, nal_class, read_bytes


def summarize(path):
    data = read_bytes(path)
    counts = Counter()
    total = 0
    for nal in iter_nals(data):
        total += 1
        counts[nal_class(nal["nal_type"])] += 1
    return total, counts


def main():
    parser = argparse.ArgumentParser(description="Compare NAL type summaries.")
    parser.add_argument("clean")
    parser.add_argument("suspect")
    args = parser.parse_args()

    clean_total, clean_counts = summarize(args.clean)
    suspect_total, suspect_counts = summarize(args.suspect)

    print(f"CLEAN_TOTAL_NALS={clean_total}")
    print(f"CLEAN_VCL={clean_counts['VCL']}")
    print(f"CLEAN_FILLER={clean_counts['FILLER']}")
    print(f"SUSPECT_TOTAL_NALS={suspect_total}")
    print(f"SUSPECT_VCL={suspect_counts['VCL']}")
    print(f"SUSPECT_FILLER={suspect_counts['FILLER']}")
    print("FILLER_DELTA=" + str(suspect_counts["FILLER"] - clean_counts["FILLER"]))


if __name__ == "__main__":
    main()
