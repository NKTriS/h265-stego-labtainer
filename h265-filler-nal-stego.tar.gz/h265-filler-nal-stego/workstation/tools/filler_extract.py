#!/usr/bin/env python3
import argparse
from hevc_filler_common import bits_to_text, filler_records, read_bytes


def main():
    parser = argparse.ArgumentParser(description="Recover a message from H.265 filler NAL length parity.")
    parser.add_argument("input")
    args = parser.parse_args()

    records = filler_records(read_bytes(args.input))
    bits = []
    for rec in records:
        # TODO 1: bit an trong parity cua so byte 0xff.
        bit = 0
        bits.append(bit)

    # TODO 2: doi day bit thanh ASCII.
    message = ""
    print(f"FILLER_BITS={len(bits)}")
    print(f"FILLER_MESSAGE={message}")


if __name__ == "__main__":
    main()
