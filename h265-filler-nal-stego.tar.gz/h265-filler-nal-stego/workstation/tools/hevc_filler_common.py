#!/usr/bin/env python3
from pathlib import Path

FD_NUT = 38


def read_bytes(path):
    return Path(path).read_bytes()


def iter_nals(data):
    starts = []
    i = 0
    size = len(data)
    while i < size - 3:
        if data[i:i + 3] == b"\x00\x00\x01":
            starts.append((i, 3))
            i += 3
        elif i < size - 4 and data[i:i + 4] == b"\x00\x00\x00\x01":
            starts.append((i, 4))
            i += 4
        else:
            i += 1

    for idx, (start, start_len) in enumerate(starts):
        header = start + start_len
        end = starts[idx + 1][0] if idx + 1 < len(starts) else size
        if header + 2 > end:
            continue
        nal_type = (data[header] >> 1) & 0x3f
        layer_id = ((data[header] & 0x01) << 5) | (data[header + 1] >> 3)
        temporal_id = data[header + 1] & 0x07
        payload = data[header + 2:end]
        yield {
            "index": idx,
            "start": start,
            "header": header,
            "payload_start": header + 2,
            "end": end,
            "nal_type": nal_type,
            "layer_id": layer_id,
            "temporal_id": temporal_id,
            "payload": payload,
            "payload_len": len(payload),
        }


def nal_class(nal_type):
    if 0 <= nal_type <= 31:
        return "VCL"
    if nal_type == FD_NUT:
        return "FILLER"
    return "NONVCL"


def filler_records(data):
    records = []
    for nal in iter_nals(data):
        if nal["nal_type"] != FD_NUT:
            continue
        ff_count = 0
        for byte in nal["payload"]:
            if byte == 0xff:
                ff_count += 1
            else:
                break
        records.append({
            "record": len(records),
            "nal_index": nal["index"],
            "offset": nal["start"],
            "payload_len": nal["payload_len"],
            "ff_count": ff_count,
            "bit": ff_count % 2,
        })
    return records


def bits_to_text(bits):
    out = bytearray()
    for i in range(0, len(bits), 8):
        chunk = bits[i:i + 8]
        if len(chunk) < 8:
            break
        value = 0
        for bit in chunk:
            value = (value << 1) | bit
        out.append(value)
    return out.decode("ascii", errors="replace")
