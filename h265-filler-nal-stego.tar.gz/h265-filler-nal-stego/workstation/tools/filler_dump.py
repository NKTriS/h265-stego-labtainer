#!/usr/bin/env python3
import argparse
from hevc_filler_common import filler_records, read_bytes


def main():
    parser = argparse.ArgumentParser(description="Dump H.265 filler-data NAL records.")
    parser.add_argument("input")
    args = parser.parse_args()

    records = filler_records(read_bytes(args.input))
    print("rec nal offset payload_len ff_count parity")
    for rec in records:
        print(
            f"{rec['record']:03d} {rec['nal_index']:03d} {rec['offset']:06d} "
            f"{rec['payload_len']:03d} {rec['ff_count']:03d} {rec['bit']}"
        )
    print(f"FILLER_RECORDS={len(records)}")
    print("CHANNEL_HINT=ff_count parity")


if __name__ == "__main__":
    main()
