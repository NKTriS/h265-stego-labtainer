# Hướng dẫn bài lab h265-filler-nal-stego

## Giới thiệu chung

Một hệ thống kho hàng bị nghi rò rỉ dữ liệu qua video camera H.265. SOC thu được hai file: một bản sạch dùng để đối chiếu và một bản nghi vấn đã được xuất ra ngoài. Cả hai file đều là video H.265 thật, có thể kiểm tra bằng `ffprobe` và có thể xuất frame bằng `ffmpeg`.

Khác với các bài trước, lab này không dùng SEI, không nối payload ở cuối file, không dùng AUD, không dùng motion vector, không dùng intra prediction và không dùng lượng tử/QP. Kênh giấu tin nằm trong **Filler Data NAL** của H.265. Đây là loại NAL hợp lệ, decoder thường bỏ qua khi phát video. Bit được giấu bằng parity của số byte `0xff` trong mỗi Filler NAL:

```text
số byte 0xff chẵn -> bit 0
số byte 0xff lẻ   -> bit 1
```

## Mục tiêu

Sinh viên cần biết cách kiểm tra video H.265, so sánh bản sạch với bản nghi vấn, quét NAL unit, nhận ra Filler NAL bất thường, sửa một đoạn extractor nhỏ và viết kết luận điều tra.

## Thực hành

### Task 1 - So sánh hai file chứng cứ

Xem thư mục evidence:

```bash
ls evidence
```

Tính hash cho hai file và lưu output:

```bash
sha256sum evidence/warehouse-clean.hevc evidence/warehouse-suspect.hevc > sha256sum.stdout
cat sha256sum.stdout
```

Hai hash khác nhau chứng minh bản nghi vấn đã bị thay đổi.

### Task 2 - Xác nhận video vẫn là H.265 thật

Kiểm tra nhanh bằng `file`:

```bash
file evidence/warehouse-clean.hevc
file evidence/warehouse-suspect.hevc
```

Kiểm tra bằng `ffprobe` và lưu output:

```bash
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,r_frame_rate -of default=noprint_wrappers=1 evidence/warehouse-suspect.hevc > ffprobe.stdout
cat ffprobe.stdout
```

Trong output cần thấy `codec_name=hevc`.

Nếu muốn kiểm tra video có thể xem được, xuất một frame:

```bash
ffmpeg -v error -i evidence/warehouse-suspect.hevc -frames:v 1 suspect_frame.jpg
ls -lh suspect_frame.jpg
```

### Task 3 - So sánh số lượng NAL

Chạy tool so sánh NAL:

```bash
python3 tools/nal_compare.py evidence/warehouse-clean.hevc evidence/warehouse-suspect.hevc > nal_compare.py.stdout
cat nal_compare.py.stdout
```

Quan sát `SUSPECT_FILLER`. Nếu bản nghi vấn có nhiều Filler NAL hơn bản sạch, đó là dấu hiệu cần phân tích tiếp.

### Task 4 - Dump Filler NAL

Chạy tool dump Filler NAL:

```bash
python3 tools/filler_dump.py evidence/warehouse-suspect.hevc > filler_dump.py.stdout
cat filler_dump.py.stdout
```

Quan sát cột `ff_count` và `parity`. Đây là dữ liệu gợi ý kênh giấu tin.

### Task 5 - Sửa extractor

Mở extractor:

```bash
nano tools/filler_extract.py
```

Trong file có hai dòng `TODO`. Sửa theo quy tắc:

```python
bit = rec["ff_count"] % 2
message = bits_to_text(bits)
```

Chạy lại tool và lưu output:

```bash
python3 tools/filler_extract.py evidence/warehouse-suspect.hevc > filler_extract.py.stdout
cat filler_extract.py.stdout
```

Nếu sửa đúng, tool sẽ in ra `FILLER_MESSAGE`.

### Task 6 - Đối chiếu log audit

Đọc log:

```bash
cat evidence/export_audit.log
```

Tìm dòng upload:

```bash
grep uploaded evidence/export_audit.log > grep.stdout
cat grep.stdout
```

Ghi lại user đã upload file nghi vấn.

### Task 7 - Viết kết luận

Tạo file `answer.txt`:

```bash
nano answer.txt
```

Trong một dòng, ghi đủ ba thông tin:

```text
<user_dang_ngo> <thong_diep_khoi_phuc> FILLER_NAL_LENGTH
```

Kiểm tra kết quả:

```bash
checkwork h265-filler-nal-stego
```
