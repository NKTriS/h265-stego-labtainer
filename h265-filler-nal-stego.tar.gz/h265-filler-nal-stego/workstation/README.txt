H.265 Filler NAL Stego

Lab nay co hai file HEVC that:
- evidence/warehouse-clean.hevc
- evidence/warehouse-suspect.hevc

Ca hai co the kiem tra bang ffprobe va co the xuat frame bang ffmpeg.
Thong diep duoc giau trong Filler Data NAL (FD_NUT), bang parity cua so byte 0xff.

Xem video trong container:
  ffplay -loglevel error -x 640 -y 360 evidence/warehouse-suspect.hevc
Hoac dung alias:
  play-suspect
  play-clean
