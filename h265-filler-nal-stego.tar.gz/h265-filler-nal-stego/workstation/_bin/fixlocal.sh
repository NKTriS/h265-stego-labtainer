#!/bin/bash

set -e

MARKER="# H265_FILLER_X11_DEFAULTS"

if ! grep -q "$MARKER" "$HOME/.bashrc" 2>/dev/null; then
    cat >> "$HOME/.bashrc" <<'EOF'

# H265_FILLER_X11_DEFAULTS
export DISPLAY="${DISPLAY:-:0}"
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/tmp}"
alias play-suspect='DISPLAY=${DISPLAY:-:0} XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/tmp} ffplay -loglevel error -x 640 -y 360 ~/evidence/warehouse-suspect.hevc'
alias play-clean='DISPLAY=${DISPLAY:-:0} XDG_RUNTIME_DIR=${XDG_RUNTIME_DIR:-/tmp} ffplay -loglevel error -x 640 -y 360 ~/evidence/warehouse-clean.hevc'
EOF
fi

mkdir -p /tmp/.X11-unix
if [ -e /var/tmp/.X11-unix/X0 ] && [ ! -e /tmp/.X11-unix/X0 ]; then
    ln -sf /var/tmp/.X11-unix/X0 /tmp/.X11-unix/X0
fi

exit 0
