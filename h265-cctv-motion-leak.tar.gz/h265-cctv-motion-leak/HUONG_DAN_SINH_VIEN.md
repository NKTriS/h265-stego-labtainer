# Bài lab: h265-cctv-motion-leak

## 1. Giới thiệu chung

Một công ty logistics bị lộ lịch vận chuyển hàng giá trị cao. SOC phát hiện trước thời điểm rò rỉ có một file camera H.265 được tải ra khỏi máy chủ nội bộ. Video nhìn bình thường, không có chuỗi ASCII rõ ràng, không có dấu hiệu SEI dễ thấy như bài lab trước.

Sinh viên đóng vai điều tra viên. Nhiệm vụ là lấy video từ `evidence-server`, bắt gói quá trình tải file, kiểm tra video, phân tích mẫu motion vector, khôi phục thông điệp ẩn và kết luận người dùng đáng ngờ.

Kỹ thuật giấu tin trong bài:

```text
mv_x chẵn -> bit 0
mv_x lẻ   -> bit 1
```

Thông điệp được giấu trong LSB của các mẫu `mv_x`, khác với lab trước vì không dùng SEI metadata và không dùng byte `00` ở cuối VCL.

## 2. Mục tiêu

Sau khi hoàn thành bài lab, sinh viên có thể:

- tải chứng cứ qua HTTP từ một máy chủ nội bộ;
- dùng `tcpdump` để bắt lại quá trình truyền file;
- dùng `file`, `ffprobe`, `strings` và công cụ NAL để kiểm tra video H.265;
- hiểu ý tưởng giấu tin trong motion vector;
- sửa một đoạn code Python nhỏ để trích xuất bit;
- đọc log máy chủ và viết kết luận điều tra.

## 3. Khởi động lab

Tải bài lab:

```bash
imodule https://github.com/NKTriS/h265-stego-labtainer/raw/refs/heads/main/h265-cctv-motion-leak.tar.gz
```

Nếu không có `imodule`, dùng:

```bash
curl -L https://raw.githubusercontent.com/NKTriS/h265-stego-labtainer/main/h265-cctv-motion-leak.tar.gz | tar -xz -C ~/labtainer/trunk/labs/
```

Chạy lab:

```bash
cd ~/labtainer/labtainer-student
labtainer h265-cctv-motion-leak
```

Lab có 2 container:

```text
analyst          máy làm bài của sinh viên
evidence-server  máy chủ chứa video camera và log export
```

Sinh viên chủ yếu thao tác trong terminal `analyst`.

## 4. Các bước thực hành

### Task 1: Lấy chứng cứ từ evidence-server

Tải file video từ địa chỉ:

```text
http://evidence-server/case/cctv.hevc
```

Lưu thành:

```text
cctv.hevc
```

### Task 2: Kiểm tra video thật

Dùng `file` và `ffprobe` để kiểm tra `cctv.hevc`. Kết quả `ffprobe` cần cho thấy:

```text
codec_name=hevc
```

### Task 3: Bắt gói quá trình tải file

Dùng `tcpdump` để bắt traffic HTTP tới `evidence-server`, lưu thành:

```text
transfer.pcap
```

Khi ghi pcap trong container, nên thêm tùy chọn `-Z root` để tcpdump không bị lỗi quyền ghi file. Sau khi tcpdump đang chạy, tải lại `cctv.hevc` bằng `curl` để tạo traffic. Có thể dừng tcpdump bằng `Ctrl+C`.

### Task 4: Kiểm tra không có SEI dễ thấy

Dùng `strings` để thử tìm các chuỗi rõ ràng trong video. Sau đó chạy:

```text
tools/nal_overview.py
```

với file `cctv.hevc`. Kết quả cần có:

```text
SEI_SUSPICIOUS=NO
```

Điểm cần rút ra: không thấy metadata lạ không có nghĩa là video không có kênh giấu tin.

### Task 5: Phân tích mẫu motion vector

Chạy:

```text
tools/mv_dump.py
```

với file `cctv.hevc`. Output sẽ có nhiều dòng dạng:

```text
frame=14 block=31 mv_x=...
```

Kết quả cần có:

```text
MV_RECORDS=200
```

Hãy quan sát tính chẵn/lẻ của `mv_x`.

### Task 6: Sửa code để trích xuất thông điệp

Mở file:

```text
tools/mv_extract.py
```

Hoàn thành các dòng `TODO`:

- lấy bit bằng quy tắc `mv_x chẵn/lẻ`;
- ghép 8 bit thành 1 byte theo thứ tự bit cao trước.

Sau khi sửa đúng, output cần có:

```text
MV_MESSAGE=HEVC{motion_leak_in_cctv}
```

### Task 7: Đối chiếu log máy chủ

Tải log từ:

```text
http://evidence-server/logs/cctv_export.log
```

Dùng `grep` để tìm dòng export/upload đáng ngờ. User cần phát hiện là:

```text
intern01
```

### Task 8: Viết kết luận

Tạo file:

```text
answer.txt
```

Trong file cần có đủ ba thông tin trên một dòng:

```text
intern01 HEVC{motion_leak_in_cctv} MVX_LSB
```

## 5. Kiểm tra

Từ terminal `student` bên ngoài lab, chạy:

```bash
checkwork h265-cctv-motion-leak
```

Kết quả đúng sẽ có:

```text
Y - cw1
Y - cw2
Y - cw3
Y - cw4
Y - cw5
Y - cw6
Y - cw7
Y - cw8
```

## 6. Kết thúc lab

```bash
stoplab h265-cctv-motion-leak
```
