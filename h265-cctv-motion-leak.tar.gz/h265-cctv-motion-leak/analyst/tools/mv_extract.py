#!/usr/bin/env python3
"""Recover a hidden message from mv_x parity in motion-vector samples."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from mv_common import mv_records  # noqa: E402


def bits_to_text(bits: list[int]) -> str:
    out = bytearray()
    for offset in range(0, len(bits) - 7, 8):
        value = 0
        for bit in bits[offset : offset + 8]:
            # TODO Task 6.2:
            # Ghep bit vao value theo thu tu bit cao truoc.
            value = value
        out.append(value)
    return out.decode("utf-8", errors="replace").rstrip("\x00")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()

    bits: list[int] = []
    for rec in mv_records(args.input.read_bytes()):
        # TODO Task 6.1:
        # Quy tac cua kenh an: mv_x chan -> 0, mv_x le -> 1.
        bit = 0
        bits.append(bit)

    print(f"MV_BITS={''.join(str(bit) for bit in bits)}")
    print(f"MV_MESSAGE={bits_to_text(bits)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
