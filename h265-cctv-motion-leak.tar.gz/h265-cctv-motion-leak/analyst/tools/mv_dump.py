#!/usr/bin/env python3
"""Dump simplified motion-vector samples from the CCTV HEVC bitstream."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from mv_common import mv_records  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()

    records = mv_records(args.input.read_bytes())
    for rec in records:
        print(
            f"frame={rec.frame:02d} block={rec.block:02d} "
            f"mv_x={rec.mv_x:3d} mv_y={rec.mv_y:3d}"
        )
    print(f"MV_RECORDS={len(records)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
