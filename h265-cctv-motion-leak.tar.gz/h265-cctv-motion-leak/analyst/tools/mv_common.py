"""Shared helpers for the simplified HEVC motion-vector lab tools."""

from __future__ import annotations

from dataclasses import dataclass

from nal_scan import NalUnit, parse_annex_b

MAX_RECORDS = 200


@dataclass
class MvRecord:
    frame: int
    block: int
    mv_x: int
    mv_y: int
    nal_index: int
    byte_index: int


def carrier_locations(data: bytes, limit: int = MAX_RECORDS) -> list[tuple[NalUnit, int]]:
    locations: list[tuple[NalUnit, int]] = []
    for nal in parse_annex_b(data):
        if not nal.is_vcl or len(nal.data) < 80:
            continue
        for byte_index in (23, 47):
            if byte_index < len(nal.data):
                locations.append((nal, byte_index))
                if len(locations) >= limit:
                    return locations
    return locations


def mv_records(data: bytes, limit: int = MAX_RECORDS) -> list[MvRecord]:
    records: list[MvRecord] = []
    for idx, (nal, byte_index) in enumerate(carrier_locations(data, limit)):
        raw = nal.data[byte_index]
        hidden_bit = raw & 1
        magnitude = (((raw >> 1) + idx) % 11 + 1) * 2
        mv_x = magnitude + hidden_bit
        if idx % 7 == 0:
            mv_x = -mv_x
        mv_y = ((raw >> 3) % 7) - 3
        records.append(
            MvRecord(
                frame=idx // 4,
                block=idx % 64,
                mv_x=mv_x,
                mv_y=mv_y,
                nal_index=nal.index,
                byte_index=byte_index,
            )
        )
    return records
