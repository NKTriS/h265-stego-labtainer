#!/usr/bin/env python3
"""Show a short HEVC NAL overview and flag obvious SEI/string clues."""

from __future__ import annotations

import argparse
import re
import sys
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))

from nal_scan import nal_type_name, parse_annex_b  # noqa: E402


def ascii_hits(data: bytes) -> list[str]:
    hits: list[str] = []
    for match in re.finditer(rb"[\x20-\x7e]{6,}", data):
        text = match.group().decode("ascii", errors="ignore")
        if "HEVC{" in text or "HE265LAB" in text or "SECRET" in text or "FLAG{" in text:
            hits.append(text)
    return hits


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path)
    args = parser.parse_args()

    data = args.input.read_bytes()
    nals = parse_annex_b(data)
    counts = Counter(nal.nal_type for nal in nals)
    hits = ascii_hits(data)

    print(f"TOTAL_NAL={len(nals)}")
    print(f"VCL_NAL={sum(v for k, v in counts.items() if 0 <= k <= 31)}")
    print(f"SEI_NAL={counts[39] + counts[40]}")
    print(f"ASCII_HEVC_HINTS={len(hits)}")
    print(f"SEI_SUSPICIOUS={'YES' if hits else 'NO'}")
    print()
    print("NAL_TYPE_COUNTS")
    for nal_type, count in sorted(counts.items()):
        print(f"{nal_type:02d} {nal_type_name(nal_type):12s} {count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
