# Hướng dẫn thực hành: H.265 CABAC Merge Index Stego

## 1. Mục tiêu bài lab

Bài lab này mô phỏng một kỹ thuật giấu tin khó phát hiện trong video H.265. Thông điệp không được giấu trong SEI, Filler NAL, metadata, cuối file, motion vector trực tiếp, intra prediction hay QP. Thay vào đó, bài lab sử dụng parity chẵn/lẻ của `merge_idx` trong trace merge mode.

Quy tắc giấu tin:

```text
merge_idx chẵn -> bit 0
merge_idx lẻ   -> bit 1
```

Trong lab này, video nguồn là file H.265 thật nằm trong MP4. Phần `merge_trace.csv` là trace cú pháp đã được chuẩn bị sẵn để sinh viên thao tác với kỹ thuật giấu tin mà không phải tự viết parser CABAC hoàn chỉnh.

## 2. Các file quan trọng

`evidence/warehouse-source.mp4`: video nguồn, dùng để kiểm tra codec và xuất frame quan sát.

`evidence/merge_trace.csv`: trace các block merge mode. Cột quan trọng nhất là `merge_idx`.

`evidence/message.txt`: thông điệp cần giấu.

`tools/merge_embed.py`: script cần sửa ở Task 4 để nhúng thông điệp vào trace.

`tools/merge_extract.py`: script cần sửa ở Task 6 để tách lại thông điệp từ trace stego.

`tools/merge_trace_dump.py` và `tools/build_stego_container.py`: script dùng để chạy, không cần sửa.

## 3. Thực hành

### Task 1: Xác nhận video H.265

Mục tiêu của task này là chứng minh file nguồn là video H.265 thật.

Chạy:

```bash
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,r_frame_rate -of default=noprint_wrappers=1 evidence/warehouse-source.mp4 > ffprobe.stdout
cat ffprobe.stdout
```

Dòng cần chú ý:

```text
codec_name=hevc
```

File `ffprobe.stdout` là bằng chứng cho Task 1.

### Task 2: Xuất một frame để quan sát

Mục tiêu là chứng minh video có thể giải mã và có hình ảnh xem được.

Chạy:

```bash
mkdir -p work
ffmpeg -y -i evidence/warehouse-source.mp4 -frames:v 1 work/source_frame.png > frame_export.stdout 2>&1
cat frame_export.stdout
ls -lh work/source_frame.png
```

Nếu muốn xem video trực tiếp trong container và X11 hoạt động, có thể chạy:

```bash
ffplay -loglevel error -x 640 -y 360 evidence/warehouse-source.mp4
```

Hoặc:

```bash
play-source
```

File `frame_export.stdout` là bằng chứng cho Task 2. File `work/source_frame.png` chỉ dùng để quan sát.

### Task 3: Dump merge trace

Mục tiêu là xem trace cú pháp H.265 đã chuẩn bị sẵn.

Chạy:

```bash
python3 tools/merge_trace_dump.py evidence/merge_trace.csv > merge_trace_dump.py.stdout
cat merge_trace_dump.py.stdout
```

Output cần chú ý:

```text
USABLE_MERGE_RECORDS=320
```

Các record trong trace có nhiều cột, nhưng trong bài này cần quan tâm nhất đến `merge_idx`. Khi `merge_idx` chẵn, nó biểu diễn bit 0; khi `merge_idx` lẻ, nó biểu diễn bit 1.

### Task 4: Sửa embedder để giấu tin

Mục tiêu là sửa `tools/merge_embed.py` để đọc thông điệp từ `evidence/message.txt`, chuyển thông điệp thành bit, rồi ghi từng bit vào parity của `merge_idx`.

Xem thông điệp cần giấu:

```bash
cat evidence/message.txt
```

Mở file cần sửa:

```bash
nano tools/merge_embed.py
```

Trong file có 2 vị trí TODO.

Ở TODO Task 4.1, cần làm cho:

```text
bit 0 -> merge_idx chẵn
bit 1 -> merge_idx lẻ
```

Trong lab này các carrier đều có `candidate_count >= 2`, nên có thể dùng `merge_idx = 0` cho bit 0 và `merge_idx = 1` cho bit 1.

Ở TODO Task 4.2, cần chuyển message thành danh sách bit bằng hàm `text_to_bits(message)`.

Sau khi sửa, chạy:

```bash
python3 tools/merge_embed.py evidence/merge_trace.csv evidence/message.txt work/merge_stego.csv > merge_embed.py.stdout
cat merge_embed.py.stdout
```

Output đúng cần có:

```text
MESSAGE_BITS=232
MERGE_STEGO_TRACE=work/merge_stego.csv
```

File `work/merge_stego.csv` là trace đã được nhúng thông điệp.

### Task 5: Tạo gói stego

Mục tiêu là tạo thư mục `stego/` gồm video và trace stego để mô phỏng một gói bằng chứng đã bị giấu tin.

Chạy:

```bash
python3 tools/build_stego_container.py evidence/warehouse-source.mp4 work/merge_stego.csv stego > build_stego_container.py.stdout
cat build_stego_container.py.stdout
ls -lh stego
```

Output cần chú ý:

```text
TECHNIQUE=CABAC_MERGE_IDX_PARITY
```

Sau task này, file quan trọng nhất là:

```text
stego/warehouse-merge-stego.merge.csv
```

File này sẽ được dùng ở Task 6.

### Task 6: Sửa extractor để khôi phục thông điệp

Mục tiêu là sửa `tools/merge_extract.py` để đọc lại bit từ parity của `merge_idx`.

Mở file:

```bash
nano tools/merge_extract.py
```

Trong TODO Task 6.1, cần lấy bit theo quy tắc:

```text
merge_idx chẵn -> bit 0
merge_idx lẻ   -> bit 1
```

Nói cách khác, bit cần khôi phục là phần dư khi `merge_idx` chia cho 2.

Sau khi sửa, chạy:

```bash
python3 tools/merge_extract.py stego/warehouse-merge-stego.merge.csv > merge_extract.py.stdout
cat merge_extract.py.stdout
```

Output đúng cần có:

```text
MERGE_MESSAGE=HEVC{cabac_merge_idx_channel}
```

Nếu output ra ký tự lạ, thường là do lấy sai parity hoặc Task 4 chưa nhúng đúng.

### Task 7: Đối chiếu ghi chú sự cố

Mục tiêu là tìm tài khoản đáng ngờ trong ghi chú sự cố.

Chạy:

```bash
cat evidence/incident_note.txt
grep cam-admin evidence/incident_note.txt > grep.stdout
cat grep.stdout
```

File `grep.stdout` cần có:

```text
cam-admin
```

### Task 8: Viết kết luận

Tạo file `answer.txt`:

```bash
nano answer.txt
```

Trong một dòng, ghi đủ 3 thông tin:

```text
cam-admin HEVC{cabac_merge_idx_channel} CABAC_MERGE_IDX
```

Ý nghĩa:

`cam-admin`: tài khoản đáng ngờ.

`HEVC{cabac_merge_idx_channel}`: thông điệp khôi phục được.

`CABAC_MERGE_IDX`: kỹ thuật giấu tin được sử dụng.

## 4. Kiểm tra

Từ terminal `student`, chạy:

```bash
checkwork h265-cabac-merge-stego
```

Nếu một task chưa lên `Y`, quay lại đúng file output của task đó để kiểm tra. Ví dụ Task 6 chấm file `merge_extract.py.stdout`, nên cần chắc chắn file này có dòng `MERGE_MESSAGE=HEVC{cabac_merge_idx_channel}`.
