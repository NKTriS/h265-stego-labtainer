# Hướng dẫn thực hành: H.265 CABAC Merge Index Stego

## 1. Mục tiêu bài lab

Bài lab này mô phỏng một kỹ thuật giấu tin khó phát hiện trong video H.265. Thông điệp không được giấu trong SEI, Filler NAL, metadata, cuối file, motion vector trực tiếp, intra prediction hay QP. Thay vào đó, bài lab sử dụng parity chẵn/lẻ của `merge_idx` trong trace merge mode.

Quy tắc giấu tin:

```text
merge_idx chẵn -> bit 0
merge_idx lẻ   -> bit 1
```

Trong lab này, video nguồn là file H.265 thật nằm trong MP4. Phần `merge_trace.csv` là trace cú pháp đã được chuẩn bị sẵn để sinh viên thao tác với kỹ thuật giấu tin mà không phải tự viết parser CABAC hoàn chỉnh.

## 2. Các file quan trọng

`evidence/warehouse-source.mp4`: video nguồn, dùng để kiểm tra codec và xuất frame quan sát.

`evidence/merge_trace.csv`: trace các block merge mode. Cột quan trọng nhất là `merge_idx`.

`evidence/message.txt`: thông điệp cần giấu.

`tools/merge_embed.py`: script cần sửa ở Task 4 để nhúng thông điệp vào trace.

`tools/merge_extract.py`: script cần sửa ở Task 6 để tách lại thông điệp từ trace stego.

`tools/merge_trace_dump.py` và `tools/build_stego_container.py`: script dùng để chạy, không cần sửa.

## 3. Thực hành

### Task 1: X?c nh?n video g?c l? video th??ng

M?c ti?u c?a task n?y l? ch?ng minh file ??u v?o ch?a ph?i H.265, m? l? m?t video MP4 th?ng th??ng d?ng H.264 ?? sinh vi?n t? n?n l?i.

Ch?y:

```bash
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,r_frame_rate -of default=noprint_wrappers=1 evidence/warehouse-raw.mp4 > ffprobe_raw.stdout
cat ffprobe_raw.stdout
```

D?ng c?n ch? ?:

```text
codec_name=h264
```

File `ffprobe_raw.stdout` l? b?ng ch?ng cho Task 1.
Ghi ch?: video g?c trong `evidence/warehouse-raw.mp4` l? clip Big Buck Bunny 30 gi?y, H.264 MP4, ???c chu?n b? ? 1280x720 ?? h?nh r? h?n.


### Task 2: N?n video sang chu?n H.265

M?c ti?u l? d?ng `ffmpeg` ?? re-encode video g?c sang H.265/HEVC. File H.265 sinh ra s? ???c d?ng ? c?c b??c quan s?t v? ??ng g?i stego.

Ch?y:

```bash
mkdir -p work
ffmpeg -y -i evidence/warehouse-raw.mp4 -c:v libx265 -preset fast -x265-params crf=28 -an work/warehouse-h265.mp4 > compress.stdout 2>&1
ffprobe -v error -select_streams v:0 -show_entries stream=codec_name,width,height,r_frame_rate -of default=noprint_wrappers=1 work/warehouse-h265.mp4 >> compress.stdout
echo COMPRESSED_HEVC=work/warehouse-h265.mp4 >> compress.stdout
cat compress.stdout
ls -lh work/warehouse-h265.mp4
```

D?ng c?n ch? ?:

```text
codec_name=hevc
COMPRESSED_HEVC=work/warehouse-h265.mp4
```

File `compress.stdout` l? b?ng ch?ng cho Task 2. File `work/warehouse-h265.mp4` l? video ?? ???c n?n sang chu?n H.265.

### Task 3: Xu?t m?t frame t? video H.265 ?? quan s?t

M?c ti?u l? ch?ng minh video H.265 sau khi n?n v?n c? th? gi?i m? v? xem ???c.

Ch?y:

```bash
ffmpeg -y -i work/warehouse-h265.mp4 -frames:v 1 work/source_frame.png > frame_export.stdout 2>&1
cat frame_export.stdout
ls -lh work/source_frame.png
```

N?u mu?n xem video tr?c ti?p trong container v? X11 ho?t ??ng, c? th? ch?y:

```bash
ffplay -loglevel error -x 640 -y 360 work/warehouse-h265.mp4
```

Ho?c:

```bash
play-h265
```

N?u mu?n xem video g?c tr??c khi n?n, d?ng:

```bash
play-source
```

File `frame_export.stdout` l? b?ng ch?ng cho Task 3. File `work/source_frame.png` ch? d?ng ?? quan s?t.

### Task 4: Sửa embedder để giấu tin

Mục tiêu là sửa `tools/merge_embed.py` để đọc thông điệp từ `evidence/message.txt`, chuyển thông điệp thành bit, rồi ghi từng bit vào parity của `merge_idx`.

Xem thông điệp cần giấu:

```bash
cat evidence/message.txt
```

Mở file cần sửa:

```bash
nano tools/merge_embed.py
```

Trong file có 2 vị trí TODO.

Ở TODO Task 4.1, cần làm cho:

```text
bit 0 -> merge_idx chẵn
bit 1 -> merge_idx lẻ
```

Trong lab này các carrier đều có `candidate_count >= 2`, nên có thể dùng `merge_idx = 0` cho bit 0 và `merge_idx = 1` cho bit 1.

Ở TODO Task 4.2, cần chuyển message thành danh sách bit bằng hàm `text_to_bits(message)`.

Sau khi sửa, chạy:

```bash
python3 tools/merge_embed.py evidence/merge_trace.csv evidence/message.txt work/merge_stego.csv > merge_embed.py.stdout
cat merge_embed.py.stdout
```

Output đúng cần có:

```text
MESSAGE_BITS=232
MERGE_STEGO_TRACE=work/merge_stego.csv
```

File `work/merge_stego.csv` là trace đã được nhúng thông điệp.

### Task 5: Tạo gói stego

Mục tiêu là tạo thư mục `stego/` gồm video và trace stego để mô phỏng một gói bằng chứng đã bị giấu tin.

Chạy:

```bash
python3 tools/build_stego_container.py work/warehouse-h265.mp4 work/merge_stego.csv stego > build_stego_container.py.stdout
cat build_stego_container.py.stdout
ls -lh stego
```

Output cần chú ý:

```text
TECHNIQUE=CABAC_MERGE_IDX_PARITY
```

Sau task này, file quan trọng nhất là:

```text
stego/warehouse-merge-stego.merge.csv
```

File này sẽ được dùng ở Task 6.

### Task 6: Sửa extractor để khôi phục thông điệp

Mục tiêu là sửa `tools/merge_extract.py` để đọc lại bit từ parity của `merge_idx`.

Mở file:

```bash
nano tools/merge_extract.py
```

Trong TODO Task 6.1, cần lấy bit theo quy tắc:

```text
merge_idx chẵn -> bit 0
merge_idx lẻ   -> bit 1
```

Nói cách khác, bit cần khôi phục là phần dư khi `merge_idx` chia cho 2.

Sau khi sửa, chạy:

```bash
python3 tools/merge_extract.py stego/warehouse-merge-stego.merge.csv > merge_extract.py.stdout
cat merge_extract.py.stdout
```

Output đúng cần có:

```text
MERGE_MESSAGE=HEVC{cabac_merge_idx_channel}
```

Nếu output ra ký tự lạ, thường là do lấy sai parity hoặc Task 4 chưa nhúng đúng.

### Task 7: Đối chiếu ghi chú sự cố

Mục tiêu là tìm tài khoản đáng ngờ trong ghi chú sự cố.

Chạy:

```bash
cat evidence/incident_note.txt
grep cam-admin evidence/incident_note.txt > grep.stdout
cat grep.stdout
```

File `grep.stdout` cần có:

```text
cam-admin
```

### Task 8: Viết kết luận

Tạo file `answer.txt`:

```bash
nano answer.txt
```

Trong một dòng, ghi đủ 3 thông tin:

```text
cam-admin HEVC{cabac_merge_idx_channel} CABAC_MERGE_IDX
```

Ý nghĩa:

`cam-admin`: tài khoản đáng ngờ.

`HEVC{cabac_merge_idx_channel}`: thông điệp khôi phục được.

`CABAC_MERGE_IDX`: kỹ thuật giấu tin được sử dụng.

## 4. Kiểm tra

Từ terminal `student`, chạy:

```bash
checkwork h265-cabac-merge-stego
```

Nếu một task chưa lên `Y`, quay lại đúng file output của task đó để kiểm tra. Ví dụ Task 6 chấm file `merge_extract.py.stdout`, nên cần chắc chắn file này có dòng `MERGE_MESSAGE=HEVC{cabac_merge_idx_channel}`.
