# H.265 CABAC Merge Index Stego

Lab này cho sinh viên tự giấu tin vào trace `merge_idx` của H.265. Video nguồn là MP4/H.265 thật và có thể mở xem được. Phần giấu tin nằm ở cú pháp merge mode, không dùng SEI, Filler NAL, metadata cuối file, motion vector trực tiếp, intra prediction hoặc QP.

Quy tắc chính:

```text
merge_idx chẵn -> bit 0
merge_idx lẻ   -> bit 1
```

## Task 1 - Xác nhận video H.265

Dùng `ffprobe` để kiểm tra `evidence/warehouse-source.mp4`. Lưu output vào `ffprobe.stdout`.

## Task 2 - Xuất frame để so sánh

Dùng `ffmpeg` để xuất một frame từ video nguồn. Lưu output vào `frame_export.stdout`.

## Task 3 - Dump merge trace

Dùng `tools/merge_trace_dump.py` với `evidence/merge_trace.csv`. Lưu output vào `merge_trace_dump.py.stdout`.

## Task 4 - Sửa embedder

Mở `tools/merge_embed.py`, sửa các dòng TODO để chuyển message thành bit và ghi bit vào parity của `merge_idx`.

Tạo file `work/merge_stego.csv`, lưu output vào `merge_embed.py.stdout`.

## Task 5 - Tạo gói stego

Dùng `tools/build_stego_container.py` để tạo thư mục `stego/`. Output cần lưu vào `build_stego_container.py.stdout`.

## Task 6 - Sửa extractor

Mở `tools/merge_extract.py`, sửa TODO để đọc lại bit từ parity của `merge_idx`. Lưu output vào `merge_extract.py.stdout`.

## Task 7 - Đối chiếu ghi chú sự cố

Đọc `evidence/incident_note.txt`, dùng `grep` tìm user đã export video. Lưu output vào `grep.stdout`.

## Task 8 - Viết kết luận

Tạo `answer.txt`, trên một dòng có đủ:

```text
cam-admin
HEVC{cabac_merge_idx_channel}
CABAC_MERGE_IDX
```

Kiểm tra bằng:

```bash
checkwork h265-cabac-merge-stego
```
