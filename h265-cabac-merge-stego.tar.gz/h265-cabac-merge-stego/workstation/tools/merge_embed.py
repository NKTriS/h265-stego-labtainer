#!/usr/bin/env python3
import argparse
from merge_common import read_trace, text_to_bits, usable_rows, write_trace


def embed_bits(rows, bits):
    carriers = usable_rows(rows)
    if len(bits) > len(carriers):
        raise SystemExit(f"message too long: need {len(bits)} carriers, have {len(carriers)}")

    for index, bit in enumerate(bits):
        row = carriers[index]

        # TODO Task 4.1:
        # Store bit 0 with an even merge_idx and bit 1 with an odd merge_idx.
        # In this lab candidate_count is always >= 2 for carrier rows, so
        # merge_idx 0 and 1 are valid choices.
        row["merge_idx"] = 0

    return rows


def main():
    parser = argparse.ArgumentParser(description="Embed text into HEVC merge_idx parity trace.")
    parser.add_argument("input_trace")
    parser.add_argument("message_file")
    parser.add_argument("output_trace")
    args = parser.parse_args()

    rows = read_trace(args.input_trace)
    message = open(args.message_file).read().strip()

    # TODO Task 4.2:
    # Convert message to a list of bits with text_to_bits(message).
    bits = []

    stego_rows = embed_bits(rows, bits)
    write_trace(args.output_trace, stego_rows)

    print(f"MESSAGE_TEXT={message}")
    print(f"MESSAGE_BITS={len(bits)}")
    print(f"MERGE_STEGO_TRACE={args.output_trace}")


if __name__ == "__main__":
    main()
