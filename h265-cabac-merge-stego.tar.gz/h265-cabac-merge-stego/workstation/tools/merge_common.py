#!/usr/bin/env python3
import csv
from pathlib import Path


FIELDNAMES = [
    "record_id",
    "frame",
    "ctu_x",
    "ctu_y",
    "merge_flag",
    "candidate_count",
    "merge_idx",
    "usable",
]


def read_trace(path):
    rows = []
    with open(path, newline="") as handle:
        for row in csv.DictReader(handle):
            rows.append({key: int(row[key]) for key in FIELDNAMES})
    return rows


def write_trace(path, rows):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDNAMES)
        writer.writeheader()
        writer.writerows(rows)


def text_to_bits(text):
    bits = []
    for ch in text:
        value = ord(ch)
        for shift in range(7, -1, -1):
            bits.append((value >> shift) & 1)
    return bits


def bits_to_text(bits):
    chars = []
    for pos in range(0, len(bits), 8):
        chunk = bits[pos:pos + 8]
        if len(chunk) < 8:
            break
        value = 0
        for bit in chunk:
            value = (value << 1) | bit
        chars.append(chr(value))
    return "".join(chars)


def usable_rows(rows):
    return [row for row in rows if row["merge_flag"] == 1 and row["candidate_count"] >= 2 and row["usable"] == 1]
