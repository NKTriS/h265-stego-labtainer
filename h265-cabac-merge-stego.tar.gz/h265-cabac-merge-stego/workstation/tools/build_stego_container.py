#!/usr/bin/env python3
import argparse
import json
import shutil
import subprocess
from pathlib import Path


def codec_name(video):
    command = [
        "ffprobe",
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=codec_name",
        "-of",
        "default=noprint_wrappers=1:nokey=1",
        video,
    ]
    return subprocess.check_output(command, text=True).strip()


def main():
    parser = argparse.ArgumentParser(description="Build a stego evidence package.")
    parser.add_argument("source_video")
    parser.add_argument("stego_trace")
    parser.add_argument("output_dir")
    args = parser.parse_args()

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    out_video = out_dir / "warehouse-merge-stego.mp4"
    out_trace = out_dir / "warehouse-merge-stego.merge.csv"
    manifest = out_dir / "manifest.json"

    shutil.copy2(args.source_video, out_video)
    shutil.copy2(args.stego_trace, out_trace)
    manifest.write_text(json.dumps({
        "video": out_video.name,
        "trace": out_trace.name,
        "codec": codec_name(str(out_video)),
        "technique": "CABAC_MERGE_IDX_PARITY",
    }, indent=2))

    print(f"STEGO_VIDEO={out_video}")
    print(f"STEGO_TRACE={out_trace}")
    print(f"STREAM_CODEC={codec_name(str(out_video))}")
    print("TECHNIQUE=CABAC_MERGE_IDX_PARITY")


if __name__ == "__main__":
    main()
