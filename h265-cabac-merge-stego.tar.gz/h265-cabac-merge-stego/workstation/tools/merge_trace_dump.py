#!/usr/bin/env python3
import argparse
from merge_common import read_trace, usable_rows


def main():
    parser = argparse.ArgumentParser(description="Dump HEVC merge_idx trace records.")
    parser.add_argument("trace")
    args = parser.parse_args()

    rows = read_trace(args.trace)
    usable = usable_rows(rows)
    print("record frame ctu_x ctu_y merge_flag candidate_count merge_idx")
    for row in rows[:16]:
        print(
            f"{row['record_id']:04d}   {row['frame']:03d}   {row['ctu_x']:02d}    "
            f"{row['ctu_y']:02d}    {row['merge_flag']}          "
            f"{row['candidate_count']}               {row['merge_idx']}"
        )
    print(f"MERGE_RECORDS={len(rows)}")
    print(f"USABLE_MERGE_RECORDS={len(usable)}")


if __name__ == "__main__":
    main()
