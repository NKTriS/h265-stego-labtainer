#!/usr/bin/env python3
import argparse
from merge_common import bits_to_text, read_trace, usable_rows


def recover_bits(rows, bit_count):
    bits = []
    for row in usable_rows(rows)[:bit_count]:
        # TODO Task 6.1:
        # Recover the hidden bit from merge_idx parity.
        bit = 0
        bits.append(bit)
    return bits


def main():
    parser = argparse.ArgumentParser(description="Recover text from HEVC merge_idx parity trace.")
    parser.add_argument("stego_trace")
    parser.add_argument("--chars", type=int, default=29)
    args = parser.parse_args()

    rows = read_trace(args.stego_trace)
    bit_count = args.chars * 8
    bits = recover_bits(rows, bit_count)
    message = bits_to_text(bits)
    print(f"RECOVERED_BITS={len(bits)}")
    print(f"MERGE_MESSAGE={message}")


if __name__ == "__main__":
    main()
